package keystrokesmod.client.mixin.mixins;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Overwrite;
import org.spongepowered.asm.mixin.Shadow;

import com.mojang.authlib.GameProfile;

import keystrokesmod.client.event.EventTiming;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.event.impl.UpdateEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.movement.NoSlow;
import keystrokesmod.client.module.modules.movement.Sprint;
import net.minecraft.client.Minecraft;
import net.minecraft.client.audio.PositionedSoundRecord;
import net.minecraft.client.entity.AbstractClientPlayer;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.network.NetHandlerPlayClient;
import net.minecraft.network.play.client.C03PacketPlayer;
import net.minecraft.network.play.client.C0BPacketEntityAction;
import net.minecraft.potion.Potion;
import net.minecraft.util.MovementInput;
import net.minecraft.util.ResourceLocation;
import net.minecraft.world.World;

@Mixin(priority = 995, value = EntityPlayerSP.class)
public abstract class MixinEntityPlayerSP extends AbstractClientPlayer {

    @Shadow
    public int sprintingTicksLeft;

    public MixinEntityPlayerSP(World p_i45074_1_, GameProfile p_i45074_2_) {
        super(p_i45074_1_, p_i45074_2_);
    }

    @Override
	@Shadow
    public abstract void func_70031_b(boolean p_setSprinting_1_);

    @Shadow
    protected int sprintToggleTimer;
    @Shadow
    public float prevTimeInPortal;
    @Shadow
    public float timeInPortal;
    @Shadow
    protected Minecraft mc;
    @Shadow
    public MovementInput movementInput;

    @Override
	@Shadow
    protected abstract boolean func_145771_j(double p_pushOutOfBlocks_1_, double p_pushOutOfBlocks_3_,
            double p_pushOutOfBlocks_5_);

    @Override
	@Shadow
    public abstract void func_71016_p();

    @Shadow
    protected abstract boolean isCurrentViewEntity();

    @Shadow
    public abstract boolean isRidingHorse();

    @Shadow
    private int horseJumpPowerCounter;
    @Shadow
    private float horseJumpPower;

    @Shadow
    protected abstract void sendHorseJump();

    @Shadow
    private boolean serverSprintState;
    @Shadow
    @Final
    public NetHandlerPlayClient sendQueue;

    @Override
	@Shadow
    public abstract boolean func_70093_af();

    @Shadow
    private boolean serverSneakState;
    @Shadow
    private double lastReportedPosX;
    @Shadow
    private double lastReportedPosY;
    @Shadow
    private double lastReportedPosZ;
    @Shadow
    private float lastReportedYaw;
    @Shadow
    private float lastReportedPitch;
    @Shadow
    private int positionUpdateTicks;

    /**
     * @author mc code
     */
    @Overwrite
    public void onUpdateWalkingPlayer() {

        Raven.eventBus.post(new TickEvent());

        boolean flag = this.func_70051_ag();
        if (flag != this.serverSprintState) {
            if (flag)
				this.sendQueue
                        .func_147297_a(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.START_SPRINTING));
			else
				this.sendQueue
                        .func_147297_a(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.STOP_SPRINTING));

            this.serverSprintState = flag;
        }

        boolean flag1 = this.func_70093_af();
        if (flag1 != this.serverSneakState) {
            if (flag1)
				this.sendQueue
                        .func_147297_a(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.START_SNEAKING));
			else
				this.sendQueue
                        .func_147297_a(new C0BPacketEntityAction(this, C0BPacketEntityAction.Action.STOP_SNEAKING));

            this.serverSneakState = flag1;
        }

        if (this.isCurrentViewEntity()) {

            UpdateEvent e = new UpdateEvent(EventTiming.PRE, this.field_70165_t, this.func_174813_aQ().field_72338_b, this.field_70161_v,
                    this.field_70177_z, this.field_70125_A, this.field_70122_E);
            Raven.eventBus.post(e);

            double d0 = e.getX() - this.lastReportedPosX;
            double d1 = e.getY() - this.lastReportedPosY;
            double d2 = e.getZ() - this.lastReportedPosZ;
            double d3 = e.getYaw() - this.lastReportedYaw;
            double d4 = e.getPitch() - this.lastReportedPitch;
            boolean flag2 = (((d0 * d0) + (d1 * d1) + (d2 * d2)) > 9.0E-4D) || (this.positionUpdateTicks >= 20);
            boolean flag3 = (d3 != 0.0D) || (d4 != 0.0D);
            if (this.field_70154_o == null) {
                if (flag2 && flag3)
					this.sendQueue.func_147297_a(new C03PacketPlayer.C06PacketPlayerPosLook(e.getX(), e.getY(),
                            e.getZ(), e.getYaw(), e.getPitch(), e.isOnGround()));
				else if (flag2)
					this.sendQueue.func_147297_a(
                            new C03PacketPlayer.C04PacketPlayerPosition(e.getX(), e.getY(), e.getZ(), e.isOnGround()));
				else if (flag3)
					this.sendQueue.func_147297_a(
                            new C03PacketPlayer.C05PacketPlayerLook(e.getYaw(), e.getPitch(), e.isOnGround()));
				else
					this.sendQueue.func_147297_a(new C03PacketPlayer(e.isOnGround()));
            } else {
                this.sendQueue.func_147297_a(new C03PacketPlayer.C06PacketPlayerPosLook(this.field_70159_w, -999.0D,
                        this.field_70179_y, e.getYaw(), e.getPitch(), e.isOnGround()));
                flag2 = false;
            }

            ++this.positionUpdateTicks;
            if (flag2) {
                this.lastReportedPosX = e.getX();
                this.lastReportedPosY = e.getY();
                this.lastReportedPosZ = e.getZ();
                this.positionUpdateTicks = 0;
            }

            if (flag3) {
                this.lastReportedYaw = e.getYaw();
                this.lastReportedPitch = e.getPitch();
            }

            e = UpdateEvent.convertPost(e);
            Raven.eventBus.post(e);

        }

    }

    /**
     * @author mc code
     * @reason i tried other ways of doing this, nothing else worked
     */
    @Override
	@Overwrite
    public void func_70636_d() {
        if (this.sprintingTicksLeft > 0) {
            --this.sprintingTicksLeft;
            if (this.sprintingTicksLeft == 0)
				this.func_70031_b(false);
        }

        if (this.sprintToggleTimer > 0)
			--this.sprintToggleTimer;

        this.prevTimeInPortal = this.timeInPortal;
        if (this.field_71087_bX) {
            if ((this.mc.field_71462_r != null) && !this.mc.field_71462_r.func_73868_f())
				this.mc.func_147108_a(null);

            if (this.timeInPortal == 0.0F)
				this.mc.func_147118_V().func_147682_a(PositionedSoundRecord.func_147674_a(new ResourceLocation("portal.trigger"),
                        (this.field_70146_Z.nextFloat() * 0.4F) + 0.8F));

            this.timeInPortal += 0.0125F;
            if (this.timeInPortal >= 1.0F)
				this.timeInPortal = 1.0F;

            this.field_71087_bX = false;
        } else if (this.func_70644_a(Potion.field_76431_k)
                && (this.func_70660_b(Potion.field_76431_k).func_76459_b() > 60)) {
            this.timeInPortal += 0.006666667F;
            if (this.timeInPortal > 1.0F)
				this.timeInPortal = 1.0F;
        } else {
            if (this.timeInPortal > 0.0F)
				this.timeInPortal -= 0.05F;

            if (this.timeInPortal < 0.0F)
				this.timeInPortal = 0.0F;
        }

        if (this.field_71088_bW > 0)
			--this.field_71088_bW;

        Module noSlow = Raven.moduleManager.getModuleByClazz(NoSlow.class);
        Module sprint = Raven.moduleManager.getModuleByClazz(Sprint.class);

        boolean flag = this.movementInput.field_78901_c;
        boolean flag1 = this.movementInput.field_78899_d;
        float f = 0.8F;
        boolean flag2 = this.movementInput.field_78900_b >= f;
        this.movementInput.func_78898_a();
        if (this.func_71039_bw() && !this.func_70115_ae()) {

            MovementInput var10000 = this.movementInput;

            if (noSlow.isEnabled()) {
                float slowdown = (float) ((100 - NoSlow.b.getInput()) / 100F);
                var10000.field_78902_a *= slowdown;
                var10000.field_78900_b *= slowdown;
            } else {
                var10000.field_78902_a *= 0.2F;
                var10000.field_78900_b *= 0.2F;
                this.sprintToggleTimer = 0;
            }
        }

        this.func_145771_j(this.field_70165_t - ((double) this.field_70130_N * 0.35D), this.func_174813_aQ().field_72338_b + 0.5D,
                this.field_70161_v + ((double) this.field_70130_N * 0.35D));
        this.func_145771_j(this.field_70165_t - ((double) this.field_70130_N * 0.35D), this.func_174813_aQ().field_72338_b + 0.5D,
                this.field_70161_v - ((double) this.field_70130_N * 0.35D));
        this.func_145771_j(this.field_70165_t + ((double) this.field_70130_N * 0.35D), this.func_174813_aQ().field_72338_b + 0.5D,
                this.field_70161_v - ((double) this.field_70130_N * 0.35D));
        this.func_145771_j(this.field_70165_t + ((double) this.field_70130_N * 0.35D), this.func_174813_aQ().field_72338_b + 0.5D,
                this.field_70161_v + ((double) this.field_70130_N * 0.35D));
        boolean flag3 = ((float) this.func_71024_bL().func_75116_a() > 6.0F) || this.field_71075_bZ.field_75101_c;
        if (this.field_70122_E && !flag1 && !flag2
                && ((this.movementInput.field_78900_b >= f) || (sprint.isEnabled() && Sprint.multiDir.isToggled()
                        && ((movementInput.field_78900_b != 0) || (movementInput.field_78902_a != 0))))
                && !this.func_70051_ag() && flag3 && (!this.func_71039_bw() || noSlow.isEnabled())
                && (!this.func_70644_a(Potion.field_76440_q)
                        || (sprint.isEnabled() && Sprint.ignoreBlindness.isToggled())))
			if ((this.sprintToggleTimer <= 0) && !this.mc.field_71474_y.field_151444_V.func_151470_d())
				this.sprintToggleTimer = 7;
			else
				this.func_70031_b(true);

        if (!this.func_70051_ag()
                && ((this.movementInput.field_78900_b >= f) || (sprint.isEnabled() && Sprint.multiDir.isToggled()
                        && ((movementInput.field_78900_b != 0) || (movementInput.field_78902_a != 0))))
                && flag3 && (!this.func_71039_bw() || noSlow.isEnabled())
                && (!this.func_70644_a(Potion.field_76440_q)
                        || (sprint.isEnabled() && Sprint.ignoreBlindness.isToggled()))
                && this.mc.field_71474_y.field_151444_V.func_151470_d())
			this.func_70031_b(true);

        if (this.func_70051_ag() && (((sprint.isEnabled() && Sprint.multiDir.isToggled())
                ? !((movementInput.field_78900_b != 0) || (movementInput.field_78902_a != 0))
                : this.movementInput.field_78900_b < f) || this.field_70123_F || !flag3))
			this.func_70031_b(false);

        if (this.field_71075_bZ.field_75101_c)
			if (this.mc.field_71442_b.func_178887_k()) {
                if (!this.field_71075_bZ.field_75100_b) {
                    this.field_71075_bZ.field_75100_b = true;
                    this.func_71016_p();
                }
            } else if (!flag && this.movementInput.field_78901_c)
				if (this.field_71101_bC == 0)
					this.field_71101_bC = 7;
				else {
                    this.field_71075_bZ.field_75100_b = !this.field_71075_bZ.field_75100_b;
                    this.func_71016_p();
                    this.field_71101_bC = 0;
                }

        if (this.field_71075_bZ.field_75100_b && this.isCurrentViewEntity()) {
            if (this.movementInput.field_78899_d)
				this.field_70181_x -= this.field_71075_bZ.func_75093_a() * 3.0F;

            if (this.movementInput.field_78901_c)
				this.field_70181_x += this.field_71075_bZ.func_75093_a() * 3.0F;
        }

        if (this.isRidingHorse()) {
            if (this.horseJumpPowerCounter < 0) {
                ++this.horseJumpPowerCounter;
                if (this.horseJumpPowerCounter == 0)
					this.horseJumpPower = 0.0F;
            }

            if (flag && !this.movementInput.field_78901_c) {
                this.horseJumpPowerCounter = -10;
                this.sendHorseJump();
            } else if (!flag && this.movementInput.field_78901_c) {
                this.horseJumpPowerCounter = 0;
                this.horseJumpPower = 0.0F;
            } else if (flag) {
                ++this.horseJumpPowerCounter;
                if (this.horseJumpPowerCounter < 10)
					this.horseJumpPower = (float) this.horseJumpPowerCounter * 0.1F;
				else
					this.horseJumpPower = 0.8F + ((2.0F / (float) (this.horseJumpPowerCounter - 9)) * 0.1F);
            }
        } else
			this.horseJumpPower = 0.0F;

        super.func_70636_d();
        if (this.field_70122_E && this.field_71075_bZ.field_75100_b && !this.mc.field_71442_b.func_178887_k()) {
            this.field_71075_bZ.field_75100_b = false;
            this.func_71016_p();
        }

    }
}
