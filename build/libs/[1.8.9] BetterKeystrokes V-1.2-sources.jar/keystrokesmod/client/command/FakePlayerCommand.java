package keystrokesmod.client.command;

import com.mojang.authlib.GameProfile;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraft.command.CommandBase;
import net.minecraft.command.ICommandSender;

import java.util.UUID;

public class FakePlayerCommand extends CommandBase {
    private static final int ENTITY_ID = -8069;
    private static EntityOtherPlayerMP fakePlayer;

    @Override
    public String func_71517_b() {
        return "fakeplayer";
    }

    @Override
    public String func_71518_a(ICommandSender sender) {
        return "/fakeplayer [name|remove]";
    }

    @Override
    public int func_82362_a() {
        return 0;
    }

    @Override
    public boolean func_71519_b(ICommandSender sender) {
        return true;
    }

    @Override
    public void func_71515_b(ICommandSender sender, String[] args) {
        Minecraft mc = Minecraft.func_71410_x();
        if (!Utils.Player.isPlayerInGame()) {
            return;
        }

        if (args.length > 0 && "remove".equalsIgnoreCase(args[0])) {
            if (removeFakePlayer(mc)) {
                Utils.Player.sendMessageToSelf("&aRemoved fake player.");
            } else {
                Utils.Player.sendMessageToSelf("&cThere is no fake player to remove.");
            }
            return;
        }

        removeFakePlayer(mc);

        String fakeName = args.length > 0 ? args[0] : "FakePlayer";
        GameProfile profile = new GameProfile(UUID.randomUUID(), fakeName);
        EntityOtherPlayerMP spawnedFakePlayer = new EntityOtherPlayerMP(mc.field_71441_e, profile);

        spawnedFakePlayer.func_82149_j(mc.field_71439_g);
        spawnedFakePlayer.field_70759_as = mc.field_71439_g.field_70759_as;
        spawnedFakePlayer.field_70761_aq = mc.field_71439_g.field_70761_aq;
        spawnedFakePlayer.field_71071_by.func_70455_b(mc.field_71439_g.field_71071_by);
        spawnedFakePlayer.func_70062_b(0, mc.field_71439_g.func_70694_bm());
        spawnedFakePlayer.func_70095_a(mc.field_71439_g.func_70093_af());
        spawnedFakePlayer.func_70031_b(mc.field_71439_g.func_70051_ag());
        spawnedFakePlayer.func_82142_c(false);
        spawnedFakePlayer.field_70165_t -= Math.sin(Math.toRadians(mc.field_71439_g.field_70177_z)) * 2.0D;
        spawnedFakePlayer.field_70161_v += Math.cos(Math.toRadians(mc.field_71439_g.field_70177_z)) * 2.0D;
        spawnedFakePlayer.func_70107_b(spawnedFakePlayer.field_70165_t, spawnedFakePlayer.field_70163_u, spawnedFakePlayer.field_70161_v);

        mc.field_71441_e.func_73027_a(ENTITY_ID, spawnedFakePlayer);
        fakePlayer = spawnedFakePlayer;

        Utils.Player.sendMessageToSelf("&aSpawned fake player &e" + fakeName + "&a.");
    }

    private static boolean removeFakePlayer(Minecraft mc) {
        if (fakePlayer == null) {
            return false;
        }

        if (mc.field_71441_e != null) {
            mc.field_71441_e.func_73028_b(ENTITY_ID);
        }

        fakePlayer = null;
        return true;
    }
}
