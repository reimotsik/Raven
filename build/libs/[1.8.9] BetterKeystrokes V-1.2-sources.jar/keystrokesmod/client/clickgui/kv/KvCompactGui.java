package keystrokesmod.client.clickgui.kv;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import keystrokesmod.client.clickgui.kv.components.KvModuleSection;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.modules.client.GuiModule;
import keystrokesmod.client.utils.RenderUtils;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;

public class KvCompactGui extends GuiScreen {

    private KvSection currentSection;
    private List<KvSection> sections;

    public static int containerX, containerY, containerWidth, containerHeight, horizontalBoarderY;
    private int a;
    private boolean open;


    public KvCompactGui() {
        sections = new ArrayList<KvSection>();
        sections.add(currentSection = new KvModuleSection());
        sections.add(new KvSection("terminal"));
    }

    @Override
    public void func_73866_w_() {
        containerWidth = (int) (this.field_146294_l/1.5);
        containerHeight = (int) (this.field_146295_m/1.5);
        containerX = (this.field_146294_l/2) - (containerWidth/2);
        containerY = (this.field_146295_m/2) - (containerHeight/2);
        horizontalBoarderY = containerY + (containerHeight/6);
        KvModuleSection.initGui(containerX, containerY, containerWidth, containerHeight);
        currentSection.refresh();
        int xOffSet = 0;
        for (KvSection section : sections) {
            section.setSectionCoords(containerX + (containerWidth/3) + xOffSet, containerY + ((containerHeight/6/2 ) - (section.getHeight()/2)));
            xOffSet += section.getWidth() + 5;
        }
    }

    @Override
    public void func_73863_a(int mouseX, int mouseY, float partialTicks) {
        //drawing container
        RenderUtils.drawBorderedRoundedRect(
                containerX,
                containerY,
                containerX + containerWidth,
                containerY + containerHeight,
                7,
                3,
                Utils.Client.rainbowDraw(1, 0), 0x80000000);

        //raven icon
        Minecraft.func_71410_x().func_110434_K().func_110577_a(Raven.mResourceLocation);
        GL11.glColor4f(1f, 1f, 1f, 1f);
        Gui.func_146110_a(
                containerX + 1,
                containerY + 1,
                0,
                0,
                (horizontalBoarderY - containerY),
                (horizontalBoarderY - containerY),
                (horizontalBoarderY - containerY),
                (horizontalBoarderY - containerY));

        //drawing horizontal boarder
        Gui.func_73734_a(
                containerX,
                horizontalBoarderY,
                containerX + containerWidth,
                horizontalBoarderY + 1,
                Utils.Client.rainbowDraw(1, 0));

        for (KvSection section : sections)
            section.drawSection(mouseX, mouseY, partialTicks);

        currentSection.drawScreen(mouseX, mouseY, partialTicks);
    }

    @Override
    public void func_73864_a(int mouseX, int mouseY, int mouseButton) {
        for (KvSection section : sections) {
            if (section.mouseClicked(mouseX, mouseY, mouseButton));
            return;
        }
    }

    @Override
    public void func_146286_b(int x, int y, int button) {
        currentSection.mouseReleased(x, y, button);
    }

    public KvSection getCurrentSection() {
        return currentSection;
    }

    public void setCurrentSection(KvSection section) {
        currentSection = section;
    }

    @Override
    public void func_73869_a(char t, int k) throws IOException {
        super.func_73869_a(t, k);
        currentSection.keyTyped(t, k);
    }

    @Override
    public void func_146274_d() throws IOException {
        super.func_146274_d();
        int i = Mouse.getEventDWheel();
        i = Integer.compare(i, 0);
        currentSection.scroll(i * 5f);
    }

    @Override
    public boolean func_73868_f() {
        return false;
    }


    @Override
    public void func_146281_b() {
        Raven.configManager.save();
        Raven.clientConfig.saveConfig();
        Raven.mc.field_71474_y.field_74335_Z = GuiModule.guiScale;
    }

}
