package keystrokesmod.client.clickgui.raven;

import java.io.IOException;
import java.util.ArrayList;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import keystrokesmod.client.clickgui.raven.components.CategoryComponent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.Module.ModuleCategory;
import keystrokesmod.client.module.modules.client.GuiModule;
import keystrokesmod.client.utils.Timer;
import keystrokesmod.client.utils.Utils;
import keystrokesmod.client.utils.font.FontUtil;
import keystrokesmod.client.utils.version.Version;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.inventory.GuiInventory;

public class ClickGui extends GuiScreen {
    private ScheduledFuture<?> sf;
    private Timer aT, aL, aE, aR;
    private final ArrayList<CategoryComponent> categoryList;
    private CategoryComponent lastCategory;
    public static int mouseX, mouseY;
    public final Terminal terminal;

    public static int binding;

    public ClickGui() {
        this.terminal = new Terminal();
        this.categoryList = new ArrayList<>();
        Module.ModuleCategory[] values;
        int categoryAmount = (values = Module.ModuleCategory.values()).length;
        int xOffSet = 5;
        int yOffSet = 5;
        for (int category = 0; category < categoryAmount; ++category) {
            Module.ModuleCategory moduleCategory = values[category];
            CategoryComponent currentModuleCategory = new CategoryComponent(moduleCategory);
            currentModuleCategory.visable = (currentModuleCategory.categoryName.isShownByDefault());
            categoryList.add(currentModuleCategory);
            currentModuleCategory.setCoords(xOffSet, yOffSet);
            xOffSet = xOffSet + 100;
            if (xOffSet > 400) {
                xOffSet = 5;
                yOffSet += 120;
            }
        }
        terminal.setLocation(380, 0);
        terminal.setSize((int) (92 * 1.5), (int) ((92 * 1.5) * 0.75));
    }

    public void initMain() {
        (this.aT = this.aE = this.aR = new Timer(500.0F)).start();
        this.sf = Raven.getExecutor().schedule(() -> (this.aL = new Timer(650.0F)).start(), 650L,
                TimeUnit.MILLISECONDS);
    }

    @Override
	public void func_73866_w_() {
        super.func_73866_w_();
        categoryList.forEach(CategoryComponent::initGui);
    }

    @Override
	public void func_73863_a(int x, int y, float p) {
    	super.func_73863_a(x, y, p);
    	mouseX = x; mouseY = y;
        Version clientVersion = Raven.versionManager.getClientVersion();
        Version latestVersion = Raven.versionManager.getLatestVersion();

        func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, (int) (this.aR.getValueFloat(0.0F, 0.7F, 2) * 255.0F) << 24);
        int quarterScreenHeight = this.field_146295_m / 4;
        int halfScreenWidth = this.field_146294_l / 2;
        int w_c = 30 - this.aT.getValueInt(0, 30, 3);
        this.func_73732_a(this.field_146289_q, "r", (halfScreenWidth + 1) - w_c, quarterScreenHeight - 25,
                Utils.Client.rainbowDraw(2L, 1500L));
        this.func_73732_a(this.field_146289_q, "a", halfScreenWidth - w_c, quarterScreenHeight - 15,
                Utils.Client.rainbowDraw(2L, 1200L));
        this.func_73732_a(this.field_146289_q, "v", halfScreenWidth - w_c, quarterScreenHeight - 5,
                Utils.Client.rainbowDraw(2L, 900L));
        this.func_73732_a(this.field_146289_q, "e", halfScreenWidth - w_c, quarterScreenHeight + 5,
                Utils.Client.rainbowDraw(2L, 600L));
        this.func_73732_a(this.field_146289_q, "n", halfScreenWidth - w_c, quarterScreenHeight + 15,
                Utils.Client.rainbowDraw(2L, 300L));
        this.func_73732_a(this.field_146289_q, "b", halfScreenWidth + 1 + w_c, quarterScreenHeight + 25,
                Utils.Client.rainbowDraw(2L, 0L));
        this.func_73732_a(this.field_146289_q, "+ +", halfScreenWidth + 1 + w_c, quarterScreenHeight + 30,
                Utils.Client.rainbowDraw(2L, 0L));

        float speed = 4890;

        if (latestVersion.isNewerThan(clientVersion)) {
            int margin = 2;
            int rows = 1;
            for (int i = Raven.updateText.length - 1; i >= 0; i--) {
                String up = Raven.updateText[i];
                if (GuiModule.useCustomFont())
					FontUtil.normal.drawSmoothString(up, halfScreenWidth - (this.field_146289_q.func_78256_a(up) / 2),
                            this.field_146295_m - (this.field_146289_q.field_78288_b * rows) - margin,
                            Utils.Client.astolfoColorsDraw(10, 28, speed));
				else
					field_146297_k.field_71466_p.func_175063_a(up,
                            halfScreenWidth - (this.field_146289_q.func_78256_a(up) / 2),
                            this.field_146295_m - (this.field_146289_q.field_78288_b * rows) - margin,
                            Utils.Client.astolfoColorsDraw(10, 28, speed));
                rows++;
                margin += 2;
            }
        } else if (GuiModule.useCustomFont())
			FontUtil.normal.drawSmoothString(
		            "Raven B++ v" + clientVersion + " | Config: " + Raven.configManager.getConfig().getName(), 4,
		            this.field_146295_m - 3 - field_146297_k.field_71466_p.field_78288_b,
		            Utils.Client.astolfoColorsDraw(10, 14, speed));
		else
			field_146297_k.field_71466_p.func_175063_a(
		            "Raven B++ v" + clientVersion + " | Config: " + Raven.configManager.getConfig().getName(), 4,
		            this.field_146295_m - 3 - field_146297_k.field_71466_p.field_78288_b,
		            Utils.Client.astolfoColorsDraw(10, 14, speed));

        this.func_73728_b(halfScreenWidth - 10 - w_c, quarterScreenHeight - 30, quarterScreenHeight + 38,
                Utils.Client.customDraw(0));

        this.func_73728_b(halfScreenWidth + 10 + w_c, quarterScreenHeight - 30, quarterScreenHeight + 38,
                Utils.Client.customDraw(0));
        int animationProggress;
        if (this.aL != null) {
            animationProggress = this.aL.getValueInt(0, 20, 2);
            this.func_73730_a(halfScreenWidth - 10, (halfScreenWidth - 10) + animationProggress,
                    quarterScreenHeight - 29, Utils.Client.customDraw(0));
            this.func_73730_a(halfScreenWidth + 10, (halfScreenWidth + 10) - animationProggress,
                    quarterScreenHeight + 38, Utils.Client.customDraw(0));
        }

        visableCategoryList().forEach(category -> category.draw(x, y));

        // PLAYER
        GL11.glColor4f(1f, 1f, 1f, 1f);
        GuiInventory.func_147046_a((this.field_146294_l + 15) - this.aE.getValueInt(0, 40, 2),
                this.field_146295_m - 19 - this.field_146289_q.field_78288_b, 40, (float) (this.field_146294_l - 25 - x),
                (float) (this.field_146295_m - 50 - y), this.field_146297_k.field_71439_g);

        terminal.update(x, y);
        terminal.draw();
    }

    @Override
	public void func_73864_a(int x, int y, int mouseButton) throws IOException {
        terminal.mouseDown(x, y, mouseButton);
        for(CategoryComponent category : visableCategoryList())
            if(category.mouseDown(x, y, mouseButton)) {
                lastCategory = category;
                return;
            }
    }

    @Override
	public void func_146286_b(int x, int y, int mouseButton) {
        terminal.mouseReleased(x, y, mouseButton);
        if (terminal.overPosition(x, y))
            return;

        visableCategoryList().forEach(category -> category.mouseReleased(x, y, mouseButton));

        if (Raven.clientConfig != null)
			Raven.clientConfig.saveConfig();
    }

    @Override
	public void func_73869_a(char t, int k) {
        terminal.keyTyped(t, k);
        if(lastCategory != null)
            lastCategory.keyTyped(t, k);
        if (k == 1) {
            Raven.mc.func_147108_a(null);
            Raven.configManager.save();
            Raven.clientConfig.saveConfig();
        }
    }

    @Override
	public void func_146274_d() throws IOException {
        super.func_146274_d();
        int i = Mouse.getEventDWheel() * 5;
        visableCategoryList().forEach(category -> {
            if(category.isMouseOver(mouseX, mouseY))
                category.scroll(i);
            });
    }

    @Override
	public void func_146281_b() {
        visableCategoryList().forEach(CategoryComponent::guiClosed);
        Raven.configManager.save();
        Raven.clientConfig.saveConfig();
    }

    @Override
	public boolean func_73868_f() {
        return false;
    }

    public ArrayList<CategoryComponent> getCategoryList() {
        return categoryList;
    }

    public CategoryComponent getCategoryComponent(ModuleCategory mCat) {
        for (CategoryComponent cc : categoryList)
			if (cc.categoryName == mCat)
                return cc;
        return null;
    }

    public ArrayList<CategoryComponent> visableCategoryList() {
        ArrayList<CategoryComponent> newList = (ArrayList<CategoryComponent>) categoryList.clone();
        newList.removeIf(obj -> !obj.visable);
        return newList;
    }

    public void resetSort() {
        int xOffSet = 5;
        int yOffSet = 5;
        for(CategoryComponent category : categoryList) {
            category.setCoords(xOffSet, yOffSet);
            xOffSet = xOffSet + 100;
            if (xOffSet > 400) {
                xOffSet = 5;
                yOffSet += 120;
            }
        }

    }
}
