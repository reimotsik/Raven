package keystrokesmod.client.utils;

import net.minecraft.client.Minecraft;

public class RotationUtil {

    public static final Minecraft mc = Minecraft.func_71410_x();

    public static float pitchToBlockFace(float x, float y, float z) {



        return 70;
    }
}
