package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DoubleSliderSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.utils.CoolDown;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Mouse;

public class AutoBlock extends Module {
    public static DoubleSliderSetting duration, distance;
    public static SliderSetting chance;
    private boolean engaged;
    private final CoolDown engagedTime = new CoolDown(0);

    public AutoBlock() {
        super("AutoBlock", ModuleCategory.combat);

        this.registerSetting(duration = new DoubleSliderSetting("Block duration (MS)", 20, 100, 1, 500, 1));
        this.registerSetting(distance = new DoubleSliderSetting("Distance to player (blocks)", 0, 3, 0, 6, 0.01));
        this.registerSetting(chance = new SliderSetting("Chance %", 100, 0, 100, 1));
    }

    @Subscribe
    public void onRender(Render2DEvent e) {
        if (!Utils.Player.isPlayerInGame() || !Utils.Player.isPlayerHoldingSword())
            return;

        if (engaged) {
            if ((engagedTime.hasFinished() || !Mouse.isButtonDown(0))
                    && duration.getInputMin() <= engagedTime.getElapsedTime()) {
                engaged = false;
                release();
            }
            return;
        }

        if (Mouse.isButtonDown(0) && mc.field_71476_x != null && mc.field_71476_x.field_72308_g != null
                && mc.field_71439_g.func_70032_d(mc.field_71476_x.field_72308_g) >= distance.getInputMin()
                && mc.field_71476_x.field_72308_g != null
                && mc.field_71439_g.func_70032_d(mc.field_71476_x.field_72308_g) <= distance.getInputMax()
                && (chance.getInput() == 100 || Math.random() <= chance.getInput() / 100)) {
            engaged = true;
            engagedTime.setCooldown((long) duration.getInputMax());
            engagedTime.start();
            press();
        }
    }

    private static void release() {
        int key = mc.field_71474_y.field_74313_G.func_151463_i();
        KeyBinding.func_74510_a(key, false);
        Utils.Client.setMouseButtonState(1, false);
    }

    private static void press() {
        int key = mc.field_71474_y.field_74313_G.func_151463_i();
        KeyBinding.func_74510_a(key, true);
        KeyBinding.func_74507_a(key);
        Utils.Client.setMouseButtonState(1, true);
    }
}
