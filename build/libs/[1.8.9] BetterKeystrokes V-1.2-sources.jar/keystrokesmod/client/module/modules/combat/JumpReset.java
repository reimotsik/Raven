package keystrokesmod.client.module.modules.combat;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.PacketEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import net.minecraft.network.play.server.S12PacketEntityVelocity;

public class JumpReset extends Module {

    public JumpReset() {
        super("JumpReset", ModuleCategory.combat);

        this.registerSetting(new DescriptionSetting("Auto Jump Reset. That's it."));
    }

    @Subscribe
    public void onPacket(PacketEvent e) {
        if (e.isIncoming()) {
            if (e.getPacket() instanceof S12PacketEntityVelocity) {
                if (((S12PacketEntityVelocity) e.getPacket()).func_149412_c() == mc.field_71439_g.func_145782_y()) {
                    if(mc.field_71439_g.field_70122_E) {
                        mc.field_71439_g.func_70664_aZ();
                    }
                }
            }
        }
    }

}
