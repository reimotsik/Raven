package keystrokesmod.client.module.modules.combat;

import java.awt.Color;

import org.lwjgl.opengl.GL11;

import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.world.AntiBot;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.renderer.RenderGlobal;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.util.AxisAlignedBB;
import net.minecraft.util.MovingObjectPosition;

public class HitBox extends Module {
    public static SliderSetting a;
    public static TickSetting b;
    private static MovingObjectPosition mv;

    public HitBox() {
        super("HitBoxes", ModuleCategory.combat);
        this.registerSetting(new DescriptionSetting("Changed from multiplier to extra blocks!"));
        this.registerSetting(a = new SliderSetting("Extra Blocks", 0.2D, 0.05D, 2.0D, 0.05D));
        this.registerSetting(b = new TickSetting("Vertical", false));
    }

    /*
    @Subscribe
    public void onRenderWorldLast(ForgeEvent fe) {
        if (fe.getEvent() instanceof RenderWorldLastEvent) {
            if (b.isToggled() && Utils.Player.isPlayerInGame()) {
                for (Entity en : mc.theWorld.loadedEntityList) {
                    if (en != mc.thePlayer && en instanceof EntityLivingBase && ((EntityLivingBase) en).deathTime == 0
                            && !(en instanceof EntityArmorStand) && !en.isInvisible()) {
                        this.rh(en, Color.WHITE);
                    }
                }
            }
        }
    }

     */

    public static double exp(Entity en) {
        Module hitBox = Raven.moduleManager.getModuleByClazz(HitBox.class);
        return ((hitBox != null) && hitBox.isEnabled() && !AntiBot.bot(en)) ? a.getInput() : 0D;
    }

    private void rh(Entity e, Color c) {
        if (e instanceof EntityLivingBase) {
            double x = (e.field_70142_S + ((e.field_70165_t - e.field_70142_S) * (double) Utils.Client.getTimer().field_74281_c))
                    - mc.func_175598_ae().field_78730_l;
            double y = (e.field_70137_T + ((e.field_70163_u - e.field_70137_T) * (double) Utils.Client.getTimer().field_74281_c))
                    - mc.func_175598_ae().field_78731_m;
            double z = (e.field_70136_U + ((e.field_70161_v - e.field_70136_U) * (double) Utils.Client.getTimer().field_74281_c))
                    - mc.func_175598_ae().field_78728_n;
            float ex = (float) ((double) e.func_70111_Y() * a.getInput());
            AxisAlignedBB bbox = e.func_174813_aQ().func_72314_b(ex, ex, ex);
            AxisAlignedBB axis = new AxisAlignedBB((bbox.field_72340_a - e.field_70165_t) + x, (bbox.field_72338_b - e.field_70163_u) + y,
                    (bbox.field_72339_c - e.field_70161_v) + z, (bbox.field_72336_d - e.field_70165_t) + x, (bbox.field_72337_e - e.field_70163_u) + y, (bbox.field_72334_f - e.field_70161_v) + z);
            GL11.glBlendFunc(770, 771);
            GL11.glEnable(3042);
            GL11.glDisable(3553);
            GL11.glDisable(2929);
            GL11.glDepthMask(false);
            GL11.glLineWidth(2.0F);
            GL11.glColor3d(c.getRed(), c.getGreen(), c.getBlue());
            RenderGlobal.func_181561_a(axis);
            GL11.glEnable(3553);
            GL11.glEnable(2929);
            GL11.glDepthMask(true);
            GL11.glDisable(3042);
        }
    }
}