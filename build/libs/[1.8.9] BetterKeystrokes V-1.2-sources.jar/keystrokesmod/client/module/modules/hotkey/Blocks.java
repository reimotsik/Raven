package keystrokesmod.client.module.modules.hotkey;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;

public class Blocks extends Module {
    private final TickSetting preferSlot;
    private final SliderSetting hotbarSlotPreference;

    public Blocks() {
        super("Blocks", ModuleCategory.hotkey);

        this.registerSetting(preferSlot = new TickSetting("Prefer a slot", false));
        this.registerSetting(hotbarSlotPreference = new SliderSetting("Prefer wich slot", 9, 1, 9, 1));
    }

    @Override
    public void onEnable() {
        if (!Utils.Player.isPlayerInGame())
            return;

        if (preferSlot.isToggled()) {
            int preferedSlot = (int) hotbarSlotPreference.getInput() - 1;

            ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(preferedSlot);
            if (itemInSlot != null && itemInSlot.func_77973_b() instanceof ItemBlock) {
                mc.field_71439_g.field_71071_by.field_70461_c = preferedSlot;
                this.disable();
                return;
            }
        }

        for (int slot = 0; slot <= 8; slot++) {
            ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);
            if (itemInSlot != null && itemInSlot.func_77973_b() instanceof ItemBlock
                    && (((ItemBlock) itemInSlot.func_77973_b()).func_179223_d().func_149730_j()
                            || ((ItemBlock) itemInSlot.func_77973_b()).func_179223_d().func_149686_d())) {
                if (mc.field_71439_g.field_71071_by.field_70461_c != slot) {
                    mc.field_71439_g.field_71071_by.field_70461_c = slot;
                } else {
                    return;
                }
                this.disable();
                return;
            }
        }
        this.disable();
    }
}
