package keystrokesmod.client.module.modules.hotkey;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.item.*;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;

public class Healing extends Module {
    private final TickSetting preferSlot;
    private final SliderSetting hotbarSlotPreference;
    private final ComboSetting itemMode;
    private final HealingItems mode = HealingItems.HEAL_POT;

    public Healing() {
        super("Healing", ModuleCategory.hotkey);

        this.registerSetting(preferSlot = new TickSetting("Prefer a slot", false));
        this.registerSetting(hotbarSlotPreference = new SliderSetting("Prefer wich slot", 8, 1, 9, 1));
        this.registerSetting(itemMode = new ComboSetting("Mode:", mode));
    }

    @Override
    public void onEnable() {
        if (!Utils.Player.isPlayerInGame())
            return;

        if (preferSlot.isToggled()) {
            int preferedSlot = (int) hotbarSlotPreference.getInput() - 1;

            if (itemMode.getMode() == HealingItems.SOUP && isSoup(preferedSlot)) {
                mc.field_71439_g.field_71071_by.field_70461_c = preferedSlot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.GAPPLE && isGapple(preferedSlot)) {
                mc.field_71439_g.field_71071_by.field_70461_c = preferedSlot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.FOOD && isFood(preferedSlot)) {
                mc.field_71439_g.field_71071_by.field_70461_c = preferedSlot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.ALL
                    && (isGapple(preferedSlot) || isFood(preferedSlot) || isSoup(preferedSlot))) {
                mc.field_71439_g.field_71071_by.field_70461_c = preferedSlot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.HEAL_POT && (isHPot(preferedSlot))) {
                mc.field_71439_g.field_71071_by.field_70461_c = preferedSlot;
                this.disable();
                return;
            }

        }

        for (int slot = 0; slot <= 8; slot++) {
            if (itemMode.getMode() == HealingItems.SOUP && isSoup(slot)) {
                mc.field_71439_g.field_71071_by.field_70461_c = slot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.GAPPLE && isGapple(slot)) {
                mc.field_71439_g.field_71071_by.field_70461_c = slot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.FOOD && isFood(slot)) {
                mc.field_71439_g.field_71071_by.field_70461_c = slot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.ALL && (isGapple(slot) || isFood(slot) || isSoup(slot))) {
                mc.field_71439_g.field_71071_by.field_70461_c = slot;
                this.disable();
                return;
            } else if (itemMode.getMode() == HealingItems.HEAL_POT && isHPot(slot)) {
                mc.field_71439_g.field_71071_by.field_70461_c = slot;
                this.disable();
                System.out.println("a");
                return;
            }
        }
        this.disable();
    }

    public static boolean checkSlot(int slot) {
        ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);

        return itemInSlot != null && itemInSlot.func_82833_r().equalsIgnoreCase("ladder");
    }

    public enum HealingItems {
        SOUP, GAPPLE,
        // NOTCH_APPLE,
        // HEAD,
        FOOD, HEAL_POT, ALL
    }

    public boolean isSoup(int slot) {
        ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);
        if (itemInSlot == null)
            return false;
        return itemInSlot.func_77973_b() instanceof ItemSoup;
    }

    public boolean isGapple(int slot) {
        ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);
        if (itemInSlot == null)
            return false;

        return itemInSlot.func_77973_b() instanceof ItemAppleGold;
    }

    public boolean isHPot(int slot) {
        ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);
        if (itemInSlot == null)
            return false;

        if (itemInSlot.func_77973_b() instanceof ItemPotion) {
            ItemPotion ip = (ItemPotion) itemInSlot.func_77973_b();
            Utils.Player.sendMessageToSelf("" + slot);
            for (PotionEffect pe : ip.func_77832_l(itemInSlot)) {
                if (pe.func_76456_a() == Potion.field_76432_h.field_76415_H) {
                    return true;
                }
            }

        }

        return false;
    }

    public boolean isHead(int slot) {
        ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);
        if (itemInSlot == null)
            return false;

        return itemInSlot.func_77973_b() instanceof Item;
    }

    public boolean isFood(int slot) {
        ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);
        if (itemInSlot == null)
            return false;

        return itemInSlot.func_77973_b() instanceof ItemFood;
    }
}
