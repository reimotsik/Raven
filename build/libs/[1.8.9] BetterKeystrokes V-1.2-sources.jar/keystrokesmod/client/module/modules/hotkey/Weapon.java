package keystrokesmod.client.module.modules.hotkey;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.utils.Utils;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import net.minecraft.item.ItemStack;

public class Weapon extends Module {
    public Weapon() {
        super("Weapon", ModuleCategory.hotkey);
    }

    @Override
    public void onEnable() {
        if (!Utils.Player.isPlayerInGame())
            return;

        int index = -1;
        double damage = -1;

        for (int slot = 0; slot <= 8; slot++) {
            ItemStack itemInSlot = mc.field_71439_g.field_71071_by.func_70301_a(slot);
            if (itemInSlot == null)
                continue;
            for (AttributeModifier mooommHelp : itemInSlot.func_111283_C().values()) {
                if (mooommHelp.func_111164_d() > damage) {
                    damage = mooommHelp.func_111164_d();
                    index = slot;
                }
            }

        }
        if (index > -1 && damage > -1) {
            if (mc.field_71439_g.field_71071_by.field_70461_c != index) {
                Utils.Player.hotkeyToSlot(index);
            }
        }
        this.disable();
    }
}
