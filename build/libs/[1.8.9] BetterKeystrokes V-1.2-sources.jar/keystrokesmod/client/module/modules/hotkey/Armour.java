package keystrokesmod.client.module.modules.hotkey;

import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.item.ItemArmor;
import net.minecraft.item.ItemStack;

public class Armour extends Module {
    public static TickSetting ignoreIfAlreadyEquipped;

    public Armour() {
        super("Armour", ModuleCategory.hotkey);

        this.registerSetting(ignoreIfAlreadyEquipped = new TickSetting("Ignore if already equipped", true));
    }

    @Override
    public void onEnable() {
        if (!Utils.Player.isPlayerInGame()) {
            return;
        }

        int index = -1;
        double strength = -1;

        for (int armorType = 0; armorType < 4; armorType++) {
            index = -1;
            strength = -1;
            for (int slot = 0; slot <= 8; slot++) {
                ItemStack itemStack = mc.field_71439_g.field_71071_by.func_70301_a(slot);
                if (itemStack != null && itemStack.func_77973_b() instanceof ItemArmor) {
                    ItemArmor armorPiece = (ItemArmor) itemStack.func_77973_b();
                    if (!Utils.Player.playerWearingArmor().contains(armorPiece.field_77881_a)
                            && armorPiece.field_77881_a == armorType && ignoreIfAlreadyEquipped.isToggled()) {
                        if (armorPiece.func_82812_d().func_78044_b(armorType) > strength) {
                            strength = armorPiece.func_82812_d().func_78044_b(armorType);
                            index = slot;
                        }

                    } else if (Utils.Player.playerWearingArmor().contains(armorPiece.field_77881_a)
                            && armorPiece.field_77881_a == armorType && !ignoreIfAlreadyEquipped.isToggled()) {
                        ItemArmor playerArmor;
                        if (armorType == 0) {
                            playerArmor = (ItemArmor) mc.field_71439_g.func_82169_q(3).func_77973_b();
                        } else if (armorType == 1) {
                            playerArmor = (ItemArmor) mc.field_71439_g.func_82169_q(2).func_77973_b();
                        } else if (armorType == 2) {
                            playerArmor = (ItemArmor) mc.field_71439_g.func_82169_q(1).func_77973_b();
                        } else if (armorType == 3) {
                            playerArmor = (ItemArmor) mc.field_71439_g.func_82169_q(0).func_77973_b();
                        } else {
                            continue;
                        }

                        if (armorPiece.func_82812_d().func_78044_b(armorType) > strength
                                && armorPiece.func_82812_d().func_78044_b(armorType) > playerArmor
                                        .func_82812_d().func_78044_b(armorType)) {
                            strength = armorPiece.func_82812_d().func_78044_b(armorType);
                            index = slot;
                        }
                    } else if (!Utils.Player.playerWearingArmor().contains(armorPiece.field_77881_a)
                            && armorPiece.field_77881_a == armorType && !ignoreIfAlreadyEquipped.isToggled()) {

                        if (armorPiece.func_82812_d().func_78044_b(armorType) > strength) {
                            strength = armorPiece.func_82812_d().func_78044_b(armorType);
                            index = slot;
                        }
                    }

                }
            }
            if (index > -1 || strength > -1) {
                mc.field_71439_g.field_71071_by.field_70461_c = index;
                this.disable();
                this.onDisable();
                return;
            }
        }
        this.onDisable();
        this.disable();
    }
}
