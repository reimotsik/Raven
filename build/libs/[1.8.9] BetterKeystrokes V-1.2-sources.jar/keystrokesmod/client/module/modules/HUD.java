package keystrokesmod.client.module.modules;

import java.awt.Color;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

import org.lwjgl.opengl.GL11;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.client.FakeHud;
import keystrokesmod.client.module.setting.Setting;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.RenderUtils;
import keystrokesmod.client.utils.Utils;
import keystrokesmod.client.utils.font.FontUtil;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.fml.client.config.GuiButtonExt;

public class HUD extends Module {
    public static TickSetting editPosition, dropShadow, logo;
    public static ComboSetting logoMode;
    public static SliderSetting colourMode, logoScaleh, logoScalew;
    public static DescriptionSetting colourModeDesc, logoDesc1, logoDesc2;
    private static int hudX = 5;
    private static int hudY = 70;
    private double logoHeight;
    public static boolean e;

    private InputStream inputStream;
    private ResourceLocation ravenLogo;

    public static Utils.HUD.PositionMode positionMode;
    public static boolean showedError;
    public static final String HUDX_prefix = "HUDX~ ";
    public static final String HUDY_prefix = "HUDY~ ";

    public enum lmv {
        l1, l2, l3, l4, l5, l6, l7, CD
    }

    public HUD() {
        super("HUD", ModuleCategory.render);
        this.registerSetting(editPosition = new TickSetting("Edit position", false));
        this.registerSetting(dropShadow = new TickSetting("Drop shadow", true));
        this.registerSetting(logo = new TickSetting("Logo", true));
        this.registerSetting(colourMode = new SliderSetting("Value: ", 1, 1, 6, 1));
        this.registerSetting(colourModeDesc = new DescriptionSetting("Mode: RAVEN"));
        this.registerSetting(logoScaleh = new SliderSetting("Logo Scale height ", 1, 0, 10, 0.01));
        this.registerSetting(logoScalew = new SliderSetting("Logo Scale width ", 2, 0, 10, 0.01));
        this.registerSetting(logoMode = new ComboSetting("Logo Mode:", lmv.l7));
        this.registerSetting(logoDesc1 = new DescriptionSetting("cd logomode put an image logo.png"));
        this.registerSetting(logoDesc1 = new DescriptionSetting("in the keystrokes folder"));
        showedError = false;
        showInHud = false;
    }

    private void setUpLogo() {
        RenderUtils.getResourcePath("/assets/keystrokes/logohud/" + logoMode.getMode().toString() + ".png");
    }

    @Override
	public void postApplyConfig() {
        setUpLogo();
    }

    @Override
	public void guiButtonToggled(Setting b) {
        if (b == logoMode)
            setUpLogo();
        else if (b == editPosition) {
            editPosition.disable();
            mc.func_147108_a(new EditHudPositionScreen());
        }
    }

    public boolean logoLoaded() {
        return (ravenLogo != null) && logo.isToggled();
    }

    @Override
	public void guiUpdate() {
        colourModeDesc.setDesc(Utils.md + ColourModes.values()[(int) colourMode.getInput() - 1]);
    }

    @Override
	public void onEnable() {
        Raven.moduleManager.sort();
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (Utils.Player.isPlayerInGame()) {
            if ((mc.field_71462_r != null) || mc.field_71474_y.field_74330_P)
				return;
            boolean fhe = Raven.moduleManager.getModuleByName("Fake Hud").isEnabled();
            if (!e) {
                ScaledResolution sr = new ScaledResolution(mc);
                positionMode = Utils.HUD.getPostitionMode(hudX, hudY, sr.func_78326_a(), sr.func_78328_b());
                if ((positionMode == Utils.HUD.PositionMode.UPLEFT) || (positionMode == Utils.HUD.PositionMode.UPRIGHT)) {
                    if (!fhe)
						Raven.moduleManager.sortShortLong();
					else
						FakeHud.sortShortLong();
                } else if ((positionMode == Utils.HUD.PositionMode.DOWNLEFT)
                        || (positionMode == Utils.HUD.PositionMode.DOWNRIGHT))
					if (!fhe)
						Raven.moduleManager.sortLongShort();
					else
						FakeHud.sortLongShort();
                e = true;
            }
            int margin = 2;
            int y = hudY;
            int del = 0;

            List<Module> en = fhe ? FakeHud.getModules() : new ArrayList<>(Raven.moduleManager.getModules());
            if (en.isEmpty())
                return;

            int textBoxWidth = Raven.moduleManager.getLongestActiveModule(mc.field_71466_p);
            int textBoxHeight = Raven.moduleManager.getBoxHeight(mc.field_71466_p, margin);

            if (hudX < 0)
				hudX = margin;
            if (hudY < 0)
				hudY = margin;

            if ((hudX + textBoxWidth) > (mc.field_71443_c / 2))
				hudX = (mc.field_71443_c / 2) - textBoxWidth - margin;

            if ((hudY + textBoxHeight) > (mc.field_71440_d / 2))
				hudY = (mc.field_71440_d / 2) - textBoxHeight;

            drawLogo(textBoxWidth);
            y += logoHeight;
            for (Module m : en)
				if (m.isEnabled() && m.showInHud())
					if ((positionMode == Utils.HUD.PositionMode.DOWNRIGHT)
                            || (positionMode == Utils.HUD.PositionMode.UPRIGHT)) {
                        if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.RAVEN) {
                            mc.field_71466_p.func_175065_a(m.getName(),
                                    (float) hudX + (textBoxWidth - mc.field_71466_p.func_78256_a(m.getName())),
                                    (float) y, Utils.Client.rainbowDraw(2L, del), dropShadow.isToggled());
                            y += mc.field_71466_p.field_78288_b + margin;
                            del -= 120;
                        } else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.RAVEN2) {
                            mc.field_71466_p.func_175065_a(m.getName(),
                                    (float) hudX + (textBoxWidth - mc.field_71466_p.func_78256_a(m.getName())),
                                    (float) y, Utils.Client.rainbowDraw(2L, del), dropShadow.isToggled());
                            y += mc.field_71466_p.field_78288_b + margin;
                            del -= 10;
                        } else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.ASTOLFO) {
                            mc.field_71466_p.func_175065_a(m.getName(),
                                    (float) hudX + (textBoxWidth - mc.field_71466_p.func_78256_a(m.getName())),
                                    (float) y, Utils.Client.astolfoColorsDraw(10, 14), dropShadow.isToggled());
                            y += mc.field_71466_p.field_78288_b + margin;
                            del -= 120;
                        } else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.ASTOLFO2) {
                            mc.field_71466_p.func_175065_a(m.getName(),
                                    (float) hudX + (textBoxWidth - mc.field_71466_p.func_78256_a(m.getName())),
                                    (float) y, Utils.Client.astolfoColorsDraw(10, del), dropShadow.isToggled());
                            y += mc.field_71466_p.field_78288_b + margin;
                            del -= 120;
                        } else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.ASTOLFO3) {
                            mc.field_71466_p.func_175065_a(m.getName(),
                                    (float) hudX + (textBoxWidth - mc.field_71466_p.func_78256_a(m.getName())),
                                    (float) y, Utils.Client.astolfoColorsDraw(10, del), dropShadow.isToggled());
                            y += mc.field_71466_p.field_78288_b + margin;
                            del -= 10;
                        } else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.KV) {
                            FontUtil.two.drawString(m.getName(),
                                    (double) hudX + (textBoxWidth - mc.field_71466_p.func_78256_a(m.getName())), y,
                                    Utils.Client.customDraw(del), dropShadow.isToggled(), 10);
                            y += mc.field_71466_p.field_78288_b + margin;
                            del -= 10;
                        }
                    } else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.RAVEN) {
					    mc.field_71466_p.func_175065_a(m.getName(), (float) hudX, (float) y,
					            Utils.Client.rainbowDraw(2L, del), dropShadow.isToggled());
					    y += mc.field_71466_p.field_78288_b + margin;
					    del -= 120;
					} else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.RAVEN2) {
					    mc.field_71466_p.func_175065_a(m.getName(), (float) hudX, (float) y,
					            Utils.Client.rainbowDraw(2L, del), dropShadow.isToggled());
					    y += mc.field_71466_p.field_78288_b + margin;
					    del -= 10;
					} else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.ASTOLFO) {
					    mc.field_71466_p.func_175065_a(m.getName(), (float) hudX, (float) y,
					            Utils.Client.astolfoColorsDraw(10, 14), dropShadow.isToggled());
					    y += mc.field_71466_p.field_78288_b + margin;
					    del -= 120;
					} else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.ASTOLFO2) {
					    mc.field_71466_p.func_175065_a(m.getName(), (float) hudX, (float) y,
					            Utils.Client.astolfoColorsDraw(10, del), dropShadow.isToggled());
					    y += mc.field_71466_p.field_78288_b + margin;
					    del -= 120;
					} else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.ASTOLFO3) {
					    mc.field_71466_p.func_175065_a(m.getName(), (float) hudX, (float) y,
					            Utils.Client.astolfoColorsDraw(10, del), dropShadow.isToggled());
					    y += mc.field_71466_p.field_78288_b + margin;
					    del -= 10;
					} else if (ColourModes.values()[(int) colourMode.getInput() - 1] == ColourModes.KV) {
					    FontUtil.two.drawString(m.getName(), (float) hudX, (float) y, Utils.Client.customDraw(del));
					    y += mc.field_71466_p.field_78288_b - 2;
					    del -= 10;
					}
        }

    }

    private void drawLogo(int e) {

        ScaledResolution sr = new ScaledResolution(mc);
        logoHeight = (sr.func_78328_b() * logoScaleh.getInput()) / 10;
        if (logoLoaded()) {
            if ((positionMode == Utils.HUD.PositionMode.DOWNRIGHT) || (positionMode == Utils.HUD.PositionMode.UPRIGHT)) {
                double logoWidth = (sr.func_78326_a() * logoScalew.getInput()) / 8;
                Minecraft.func_71410_x().func_110434_K().func_110577_a(ravenLogo);
                GL11.glColor4f(1, 1, 1, 1);
				Gui.func_146110_a((int) ((hudX + e) - logoWidth), hudY, 0, 0, (int) logoWidth,
						(int) logoHeight, (int) logoWidth, (int) logoHeight);
            } else {
                double logoWidth = (sr.func_78326_a() * logoScalew.getInput()) / 8;
                Minecraft.func_71410_x().func_110434_K().func_110577_a(ravenLogo);
                GL11.glColor4f(1, 1, 1, 1);
                Gui.func_146110_a(hudX, hudY, 0, 0, (int) logoWidth, (int) logoHeight,
                        (int) logoWidth, (int) logoHeight);
            }
        } else
			logoHeight = 0;
    }

    static class EditHudPositionScreen extends GuiScreen {
        final String hudTextExample = "This is an-Example-HUD";
        GuiButtonExt resetPosButton;
        boolean mouseDown;
        int textBoxStartX;
        int textBoxStartY;
        ScaledResolution sr;
        int textBoxEndX;
        int textBoxEndY;
        int marginX = 5;
        int marginY = 70;
        int lastMousePosX;
        int lastMousePosY;
        int sessionMousePosX;
        int sessionMousePosY;

        @Override
		public void func_73866_w_() {
            super.func_73866_w_();
            this.field_146292_n
                    .add(this.resetPosButton = new GuiButtonExt(1, this.field_146294_l - 90, 5, 85, 20, "Reset position"));
            this.marginX = hudX;
            this.marginY = hudY;
            sr = new ScaledResolution(field_146297_k);
            positionMode = Utils.HUD.getPostitionMode(marginX, marginY, sr.func_78326_a(), sr.func_78328_b());
            e = false;
        }

        @Override
		public void func_73863_a(int mX, int mY, float pt) {
            func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, -1308622848);
            func_73734_a(0, this.field_146295_m / 2, this.field_146294_l, (this.field_146295_m / 2) + 1, 0x9936393f);
            func_73734_a(this.field_146294_l / 2, 0, (this.field_146294_l / 2) + 1, this.field_146295_m, 0x9936393f);
            int textBoxStartX = this.marginX;
            int textBoxStartY = this.marginY;
            int textBoxEndX = textBoxStartX + 50;
            int textBoxEndY = textBoxStartY + 32;
            this.drawArrayList(this.field_146297_k.field_71466_p, this.hudTextExample);
            this.textBoxStartX = textBoxStartX;
            this.textBoxStartY = textBoxStartY;
            this.textBoxEndX = textBoxEndX;
            this.textBoxEndY = textBoxEndY;
            hudX = textBoxStartX;
            hudY = textBoxStartY;
            ScaledResolution res = new ScaledResolution(this.field_146297_k);
            int descriptionOffsetX = (res.func_78326_a() / 2) - 84;
            int descriptionOffsetY = (res.func_78328_b() / 2) - 20;
            Utils.HUD.drawColouredText("Edit the HUD position by dragging.", '-', descriptionOffsetX,
                    descriptionOffsetY, 2L, 0L, true, this.field_146297_k.field_71466_p);

            try {
                this.func_146269_k();
            } catch (IOException var12) {
            }

            super.func_73863_a(mX, mY, pt);
        }

        private void drawArrayList(FontRenderer fr, String t) {
            int x = this.textBoxStartX;
            int gap = this.textBoxEndX - this.textBoxStartX;
            int y = this.textBoxStartY;
            double marginY = fr.field_78288_b + 2;
            String[] var4 = t.split("-");
            ArrayList<String> var5 = Utils.Java.toArrayList(var4);
            if ((positionMode == Utils.HUD.PositionMode.UPLEFT) || (positionMode == Utils.HUD.PositionMode.UPRIGHT))
				var5.sort((o1, o2) -> Utils.mc.fontRendererObj.getStringWidth(o2)
                        - Utils.mc.fontRendererObj.getStringWidth(o1));
			else if ((positionMode == Utils.HUD.PositionMode.DOWNLEFT)
                    || (positionMode == Utils.HUD.PositionMode.DOWNRIGHT))
				var5.sort(Comparator.comparingInt(o2 -> Utils.mc.fontRendererObj.getStringWidth(o2)));

            if ((positionMode == Utils.HUD.PositionMode.DOWNRIGHT) || (positionMode == Utils.HUD.PositionMode.UPRIGHT))
				for (String s : var5) {
                    fr.func_175065_a(s, (float) x + (gap - fr.func_78256_a(s)), (float) y, Color.white.getRGB(),
                            dropShadow.isToggled());
                    y += marginY;
                }
			else
				for (String s : var5) {
                    fr.func_175065_a(s, (float) x, (float) y, Color.white.getRGB(), dropShadow.isToggled());
                    y += marginY;
                }
        }

        @Override
		protected void func_146273_a(int mousePosX, int mousePosY, int clickedMouseButton, long timeSinceLastClick) {
            super.func_146273_a(mousePosX, mousePosY, clickedMouseButton, timeSinceLastClick);
            if (clickedMouseButton == 0)
				if (this.mouseDown) {
                    this.marginX = this.lastMousePosX + (mousePosX - this.sessionMousePosX);
                    this.marginY = this.lastMousePosY + (mousePosY - this.sessionMousePosY);
                    sr = new ScaledResolution(field_146297_k);
                    positionMode = Utils.HUD.getPostitionMode(marginX, marginY, sr.func_78326_a(),
                            sr.func_78328_b());

                    // in the else if statement, we check if the mouse is clicked AND inside the
                    // "text box"
                } else if ((mousePosX > this.textBoxStartX) && (mousePosX < this.textBoxEndX)
                        && (mousePosY > this.textBoxStartY) && (mousePosY < this.textBoxEndY)) {
                    this.mouseDown = true;
                    this.sessionMousePosX = mousePosX;
                    this.sessionMousePosY = mousePosY;
                    this.lastMousePosX = this.marginX;
                    this.lastMousePosY = this.marginY;
                }
        }

        @Override
		protected void func_146286_b(int mX, int mY, int state) {
            super.func_146286_b(mX, mY, state);
            if (state == 0)
				this.mouseDown = false;

        }

        @Override
		public void func_146284_a(GuiButton b) {
            if (b == this.resetPosButton) {
                this.marginX = hudX = 5;
                this.marginY = hudY = 70;
            }

        }

        @Override
		public boolean func_73868_f() {
            return false;
        }
    }

    public enum ColourModes {
        RAVEN, RAVEN2, ASTOLFO, ASTOLFO2, ASTOLFO3, KV
    }

    public static int getHudX() {
        return hudX;
    }

    public static int getHudY() {
        return hudY;
    }

    public static void setHudX(int hudX) {
        HUD.hudX = hudX;
    }

    public static void setHudY(int hudY) {
        HUD.hudY = hudY;
    }
}
