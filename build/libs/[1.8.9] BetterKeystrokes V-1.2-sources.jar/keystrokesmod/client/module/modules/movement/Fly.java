package keystrokesmod.client.module.modules.movement;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.Minecraft;

public class Fly extends Module {
    private final Fly.VanFly vanFly = new VanFly();
    private final Fly.GliFly gliFly = new Fly.GliFly();
    public static DescriptionSetting dc;
    public static SliderSetting a;
    public static SliderSetting b;
    private static final String c1 = "Vanilla";
    private static final String c2 = "Glide";

    public Fly() {
        super("Fly", ModuleCategory.movement);
        this.registerSetting(a = new SliderSetting("Value", 1.0D, 1.0D, 2.0D, 1.0D));
        this.registerSetting(dc = new DescriptionSetting(Utils.md + c1));
        this.registerSetting(b = new SliderSetting("Speed", 2.0D, 1.0D, 5.0D, 0.1D));
    }

    public void onEnable() {
        switch ((int) a.getInput()) {
        case 1:
            this.vanFly.onEnable();
            break;
        case 2:
            this.gliFly.onEnable();
        }

    }

    public void onDisable() {
        switch ((int) a.getInput()) {
        case 1:
            this.vanFly.onDisable();
            break;
        case 2:
            this.gliFly.onDisable();
        }

    }

    @Subscribe
    public void onTick(TickEvent e) {
        switch ((int) a.getInput()) {
        case 1:
            this.vanFly.update();
            break;
        case 2:
            this.gliFly.update();
        }

    }

    public void guiUpdate() {
        switch ((int) a.getInput()) {
        case 1:
            dc.setDesc(Utils.md + c1);
            break;
        case 2:
            dc.setDesc(Utils.md + c2);
        }

    }

    class GliFly {
        boolean opf;

        public void onEnable() {
        }

        public void onDisable() {
            this.opf = false;
        }

        public void update() {
            if (Module.mc.field_71439_g.field_71158_b.field_78900_b > 0.0F) {
                if (!this.opf) {
                    this.opf = true;
                    if (Module.mc.field_71439_g.field_70122_E) {
                        Module.mc.field_71439_g.func_70664_aZ();
                    }
                } else {
                    if (Module.mc.field_71439_g.field_70122_E || Module.mc.field_71439_g.field_70123_F) {
                        Fly.this.disable();
                        return;
                    }

                    double s = 1.94D * b.getInput();
                    double r = Math.toRadians(Module.mc.field_71439_g.field_70177_z + 90.0F);
                    Module.mc.field_71439_g.field_70159_w = s * Math.cos(r);
                    Module.mc.field_71439_g.field_70179_y = s * Math.sin(r);
                }
            }

        }
    }

    static class VanFly {
        private final float dfs = 0.05F;

        public void onEnable() {
        }

        public void onDisable() {
            if (Minecraft.func_71410_x().field_71439_g == null)
                return;

            if (Minecraft.func_71410_x().field_71439_g.field_71075_bZ.field_75100_b) {
                Minecraft.func_71410_x().field_71439_g.field_71075_bZ.field_75100_b = false;
            }

            Minecraft.func_71410_x().field_71439_g.field_71075_bZ.func_75092_a(0.05F);
        }

        public void update() {
            Module.mc.field_71439_g.field_70181_x = 0.0D;
            Module.mc.field_71439_g.field_71075_bZ.func_75092_a((float) (0.05000000074505806D * b.getInput()));
            Module.mc.field_71439_g.field_71075_bZ.field_75100_b = true;
        }
    }
}
