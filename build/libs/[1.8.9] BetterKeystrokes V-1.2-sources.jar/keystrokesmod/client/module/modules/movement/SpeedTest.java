package keystrokesmod.client.module.modules.movement;

import com.google.common.eventbus.Subscribe;

import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.utils.CoolDown;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.settings.KeyBinding;

public class SpeedTest extends Module {

    private CoolDown coolDown = new CoolDown(1);
    private SliderSetting delay, stopPercent;
    
    public SpeedTest() {
        super("SpeedTest", ModuleCategory.movement);
        this.registerSetting(delay = new SliderSetting("Delay", 20, 0, 300 ,1));
        this.registerSetting(stopPercent = new SliderSetting("Stop Percent", 0, 0, 200 ,1));
    }
    
    @Subscribe
    public void onRender2D(Render2DEvent e) {
        if(!Utils.Player.isPlayerInGame())
            return;
        if(mc.field_71439_g.field_70122_E && coolDown.hasFinished()) {
            KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), true);
            coolDown.setCooldown((long)delay.getInput());
            coolDown.start();
        }
        if(coolDown.firstFinish()) {
            mc.field_71439_g.field_70181_x *= stopPercent.getInput()/100f;
        }
    }
    
    @Override
    public void onDisable() {
        KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), false);
    }
}
