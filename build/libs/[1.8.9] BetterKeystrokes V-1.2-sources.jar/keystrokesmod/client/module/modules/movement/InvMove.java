package keystrokesmod.client.module.modules.movement;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.clickgui.raven.ClickGui;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.gui.GuiChat;
import net.minecraft.client.settings.KeyBinding;
import net.minecraft.util.EnumChatFormatting;
import org.lwjgl.input.Keyboard;

public class InvMove extends Module {

    private final DescriptionSetting ds;
    private final DescriptionSetting ds2;
    private final TickSetting undetectable;

    public InvMove() {
        super("InvMove", ModuleCategory.movement);
        registerSetting(ds = new DescriptionSetting("Does NOT work on Hypixel!"));
        registerSetting(undetectable = new TickSetting("Only ClickGui", true));
        registerSetting(ds2 = new DescriptionSetting(EnumChatFormatting.GRAY + "Only ClickGui is fully undetectable!"));
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (mc.field_71462_r != null) {
            if (mc.field_71462_r instanceof GuiChat) {
                return;
            }

            if (undetectable.isToggled() && !(mc.field_71462_r instanceof ClickGui))
                return;

            KeyBinding.func_74510_a(mc.field_71474_y.field_74351_w.func_151463_i(),
                    Keyboard.isKeyDown(mc.field_71474_y.field_74351_w.func_151463_i()));
            KeyBinding.func_74510_a(mc.field_71474_y.field_74368_y.func_151463_i(),
                    Keyboard.isKeyDown(mc.field_71474_y.field_74368_y.func_151463_i()));
            KeyBinding.func_74510_a(mc.field_71474_y.field_74366_z.func_151463_i(),
                    Keyboard.isKeyDown(mc.field_71474_y.field_74366_z.func_151463_i()));
            KeyBinding.func_74510_a(mc.field_71474_y.field_74370_x.func_151463_i(),
                    Keyboard.isKeyDown(mc.field_71474_y.field_74370_x.func_151463_i()));
            KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(),
                    Keyboard.isKeyDown(mc.field_71474_y.field_74314_A.func_151463_i()));
            EntityPlayerSP var1;
            if (Keyboard.isKeyDown(208) && mc.field_71439_g.field_70125_A < 90.0F) {
                var1 = mc.field_71439_g;
                var1.field_70125_A += 6.0F;
            }

            if (Keyboard.isKeyDown(200) && mc.field_71439_g.field_70125_A > -90.0F) {
                var1 = mc.field_71439_g;
                var1.field_70125_A -= 6.0F;
            }

            if (Keyboard.isKeyDown(205)) {
                var1 = mc.field_71439_g;
                var1.field_70177_z += 6.0F;
            }

            if (Keyboard.isKeyDown(203)) {
                var1 = mc.field_71439_g;
                var1.field_70177_z -= 6.0F;
            }
        }

    }
}
