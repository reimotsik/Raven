package keystrokesmod.client.module.modules.render;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.modules.world.AntiBot;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraftforge.client.event.RenderLivingEvent.Specials.Pre;
import org.lwjgl.opengl.GL11;

public class Nametags extends Module {
    public static SliderSetting a;
    public static TickSetting b;
    public static TickSetting c;
    public static TickSetting d;
    public static TickSetting rm;
    public static TickSetting e;

    public Nametags() {
        super("Nametags", ModuleCategory.render);
        this.registerSetting(a = new SliderSetting("Offset", 0.0D, -40.0D, 40.0D, 1.0D));
        this.registerSetting(b = new TickSetting("Rect", true));
        this.registerSetting(c = new TickSetting("Show health", true));
        this.registerSetting(d = new TickSetting("Show invis", true));
        this.registerSetting(rm = new TickSetting("Remove tags", false));
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof Pre) {
            Pre e = (Pre) fe.getEvent();

            if (rm.isToggled()) {
                e.setCanceled(true);
            } else {
                if (e.entity instanceof EntityPlayer && e.entity != mc.field_71439_g && e.entity.field_70725_aQ == 0) {
                    EntityPlayer en = (EntityPlayer) e.entity;
                    if (!d.isToggled() && en.func_82150_aj()) {
                        return;
                    }

                    if (AntiBot.bot(en) || en.getDisplayNameString().isEmpty()) {
                        return;
                    }

                    e.setCanceled(true);
                    String str = en.func_145748_c_().func_150254_d();
                    if (c.isToggled()) {
                        double r = en.func_110143_aJ() / en.func_110138_aP();
                        String h = (r < 0.3D ? "§c" : (r < 0.5D ? "§6" : (r < 0.7D ? "§e" : "§a")))
                                + Utils.Java.round(en.func_110143_aJ(), 1);
                        str = str + " " + h;
                    }

                    GlStateManager.func_179094_E();
                    GlStateManager.func_179109_b((float) e.x + 0.0F, (float) e.y + en.field_70131_O + 0.5F, (float) e.z);
                    GL11.glNormal3f(0.0F, 1.0F, 0.0F);
                    GlStateManager.func_179114_b(-mc.func_175598_ae().field_78735_i, 0.0F, 1.0F, 0.0F);
                    GlStateManager.func_179114_b(mc.func_175598_ae().field_78732_j, 1.0F, 0.0F, 0.0F);
                    float f1 = 0.02666667F;
                    GlStateManager.func_179152_a(-f1, -f1, f1);
                    if (en.func_70093_af()) {
                        GlStateManager.func_179109_b(0.0F, 9.374999F, 0.0F);
                    }

                    GlStateManager.func_179140_f();
                    GlStateManager.func_179132_a(false);
                    GlStateManager.func_179097_i();
                    GlStateManager.func_179147_l();
                    GlStateManager.func_179120_a(770, 771, 1, 0);
                    Tessellator tessellator = Tessellator.func_178181_a();
                    WorldRenderer worldrenderer = tessellator.func_178180_c();
                    int i = (int) (-a.getInput());
                    int j = mc.field_71466_p.func_78256_a(str) / 2;
                    GlStateManager.func_179090_x();
                    if (b.isToggled()) {
                        worldrenderer.func_181668_a(7, DefaultVertexFormats.field_181706_f);
                        worldrenderer.func_181662_b(-j - 1, -1 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
                        worldrenderer.func_181662_b(-j - 1, 8 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
                        worldrenderer.func_181662_b(j + 1, 8 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
                        worldrenderer.func_181662_b(j + 1, -1 + i, 0.0D).func_181666_a(0.0F, 0.0F, 0.0F, 0.25F).func_181675_d();
                        tessellator.func_78381_a();
                    }

                    GlStateManager.func_179098_w();
                    mc.field_71466_p.func_78276_b(str, -mc.field_71466_p.func_78256_a(str) / 2, i, -1);
                    GlStateManager.func_179126_j();
                    GlStateManager.func_179132_a(true);
                    GlStateManager.func_179145_e();
                    GlStateManager.func_179084_k();
                    GlStateManager.func_179131_c(1.0F, 1.0F, 1.0F, 1.0F);
                    GlStateManager.func_179121_F();
                }

            }
        }
    }
}
