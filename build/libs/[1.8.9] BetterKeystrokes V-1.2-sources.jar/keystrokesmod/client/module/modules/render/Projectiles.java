package keystrokesmod.client.module.modules.render;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.entity.EntityPlayerSP;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.item.Item;
import net.minecraft.item.ItemBow;
import net.minecraft.util.Timer;
import net.minecraft.util.Vec3;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.opengl.GL11;

public class Projectiles extends Module {

    public static SliderSetting w;

    public Projectiles() {
        super("Projectiles", ModuleCategory.render);
        this.registerSetting(w = new SliderSetting("Thickness", 2.0D, 1.0D, 10.0D, 1.0D));
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof RenderWorldLastEvent) {
            if (!Utils.Player.isPlayerInGame())
                return;
            EntityPlayerSP player = mc.field_71439_g;

            if (mc.field_71439_g.func_71045_bC() == null)
                return;
            Item stack = mc.field_71439_g.func_71045_bC().func_77973_b();
            if (stack == null)
                return;

            // check if item is throwable
            if (!(stack instanceof ItemBow))
                return;

            Timer timer = new Timer(3F);
            // calculate starting position
            double arrowPosX = player.field_70142_S + (player.field_70165_t - player.field_70142_S) * timer.field_74281_c
                    - Math.cos((float) Math.toRadians(player.field_70177_z)) * 0.16F;
            double arrowPosY = player.field_70137_T + (player.field_70163_u - player.field_70137_T) * timer.field_74281_c
                    + player.func_70047_e() - 0.1;
            double arrowPosZ = player.field_70136_U + (player.field_70161_v - player.field_70136_U) * timer.field_74281_c
                    - Math.sin((float) Math.toRadians(player.field_70177_z)) * 0.16F;

            // calculate starting motion
            float arrowMotionFactor = 1F;
            float yaw = (float) Math.toRadians(player.field_70177_z);
            float pitch = (float) Math.toRadians(player.field_70125_A);
            float arrowMotionX = (float) (-Math.sin(yaw) * Math.cos(pitch) * arrowMotionFactor);
            float arrowMotionY = (float) (-Math.sin(pitch) * arrowMotionFactor);
            float arrowMotionZ = (float) (Math.cos(yaw) * Math.cos(pitch) * arrowMotionFactor);
            double arrowMotion = Math
                    .sqrt(arrowMotionX * arrowMotionX + arrowMotionY * arrowMotionY + arrowMotionZ * arrowMotionZ);
            arrowMotionX /= arrowMotion;
            arrowMotionY /= arrowMotion;
            arrowMotionZ /= arrowMotion;
            float bowPower = (72000 - player.func_71052_bv()) / 20F;
            bowPower = (bowPower * bowPower + bowPower * 2F) / 3F;

            if (bowPower > 1F || bowPower <= 0.1F)
                bowPower = 1F;

            bowPower *= 3F;
            arrowMotionX *= bowPower;
            arrowMotionY *= bowPower;
            arrowMotionZ *= bowPower;

            // GL settings
            GL11.glPushMatrix();
            GL11.glDisable(GL11.GL_TEXTURE_2D);
            GL11.glEnable(GL11.GL_BLEND);
            GL11.glBlendFunc(GL11.GL_SRC_ALPHA, GL11.GL_ONE_MINUS_SRC_ALPHA);
            GL11.glDisable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(false);
            GL11.glEnable(GL11.GL_LINE_SMOOTH);
            GL11.glLineWidth((int) w.getInput());

            RenderManager renderManager = mc.func_175598_ae();

            // draw trajectory line
            double gravity = 0.05D;
            Vec3 playerVector = new Vec3(player.field_70165_t, player.field_70163_u + player.func_70047_e(), player.field_70161_v);
            GL11.glColor4f(0, 1, 0, 0.75F);
            GL11.glBegin(GL11.GL_LINE_STRIP);
            for (int i = 0; i < 1000; i++) {
                GL11.glVertex3d(arrowPosX - renderManager.field_78730_l, arrowPosY - renderManager.field_78731_m,
                        arrowPosZ - renderManager.field_78728_n);

                arrowPosX += arrowMotionX * 0.1;
                arrowPosY += arrowMotionY * 0.1;
                arrowPosZ += arrowMotionZ * 0.1;
                arrowMotionX *= 0.999D;
                arrowMotionY *= 0.999D;
                arrowMotionZ *= 0.999D;
                arrowMotionY -= gravity * 0.1;

                if (mc.field_71441_e.func_72933_a(playerVector, new Vec3(arrowPosX, arrowPosY, arrowPosZ)) != null)
                    break;
            }
            GL11.glEnd();

            // draw end of trajectory line
            double renderX = arrowPosX - renderManager.field_78730_l;
            double renderY = arrowPosY - renderManager.field_78731_m;
            double renderZ = arrowPosZ - renderManager.field_78728_n;

            GL11.glPushMatrix();
            GL11.glTranslated(renderX - 0.5, renderY - 0.5, renderZ - 0.5);

            GL11.glColor4f(0F, 1F, 0F, 0.25F);
            GL11.glColor4f(0, 1, 0, 0.75F);

            GL11.glPopMatrix();

            // GL resets
            GL11.glDisable(GL11.GL_BLEND);
            GL11.glEnable(GL11.GL_TEXTURE_2D);
            GL11.glEnable(GL11.GL_DEPTH_TEST);
            GL11.glDepthMask(true);
            GL11.glDisable(GL11.GL_LINE_SMOOTH);
            GL11.glPopMatrix();

        }
    }
}
