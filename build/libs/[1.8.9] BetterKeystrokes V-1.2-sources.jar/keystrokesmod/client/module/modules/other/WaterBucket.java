package keystrokesmod.client.module.modules.other;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.DimensionHelper;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.entity.player.InventoryPlayer;
import net.minecraft.init.Items;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;

import net.minecraft.util.MovingObjectPosition.MovingObjectType;
public class WaterBucket extends Module {
    public static DescriptionSetting moduleDesc;
    public static SliderSetting distance;
    private boolean handling;

    public WaterBucket() {
        super("Water bucket", ModuleCategory.other);
        this.registerSetting(moduleDesc = new DescriptionSetting("Credits: aycy"));
        this.registerSetting(moduleDesc = new DescriptionSetting("Disabled in the Nether"));
        this.registerSetting(distance = new SliderSetting("Fall Distance", 3, 1, 10, 0.1));
    }

    @Override
    public boolean canBeEnabled() {
        return !DimensionHelper.isPlayerInNether();
    }

    @Subscribe
    public void onTick(TickEvent ev) {
        if (Utils.Player.isPlayerInGame() && !mc.func_147113_T()) {
            if (DimensionHelper.isPlayerInNether())
                this.disable();

            if (this.inPosition() && this.holdWaterBucket()) {
                this.handling = true;
            }

            if (this.handling) {
                this.mlg();
                if (mc.field_71439_g.field_70122_E || mc.field_71439_g.field_70181_x > 0.0D) {
                    this.reset();
                }
            }

        }
    }

    private boolean inPosition() {
        if (mc.field_71439_g.field_70181_x < -0.6D && !mc.field_71439_g.field_70122_E && !mc.field_71439_g.field_71075_bZ.field_75100_b
                && !mc.field_71439_g.field_71075_bZ.field_75098_d && !this.handling && mc.field_71439_g.field_70143_R > distance.getInput()) {
            BlockPos playerPos = mc.field_71439_g.func_180425_c();

            for (int i = 1; i < 3; ++i) {
                BlockPos blockPos = playerPos.func_177979_c(i);
                Block block = mc.field_71441_e.func_180495_p(blockPos).func_177230_c();
                if (block.func_176212_b(mc.field_71441_e, blockPos, EnumFacing.UP)) {
                    return false;
                }
            }

            return true;
        } else {
            return false;
        }
    }

    private boolean holdWaterBucket() {
        if (this.containsItem(mc.field_71439_g.func_70694_bm(), Items.field_151131_as)) {
            return true;
        } else {
            for (int i = 0; i < InventoryPlayer.func_70451_h(); ++i) {
                if (this.containsItem(mc.field_71439_g.field_71071_by.field_70462_a[i], Items.field_151131_as)) {
                    mc.field_71439_g.field_71071_by.field_70461_c = i;
                    return true;
                }
            }

            return false;
        }
    }

    private void mlg() {
        ItemStack heldItem = mc.field_71439_g.func_70694_bm();
        if (this.containsItem(heldItem, Items.field_151131_as) && mc.field_71439_g.field_70125_A >= 70.0F) {
            MovingObjectPosition object = mc.field_71476_x;
            if (object.field_72313_a == MovingObjectType.BLOCK && object.field_178784_b == EnumFacing.UP) {
                mc.field_71442_b.func_78769_a(mc.field_71439_g, mc.field_71441_e, heldItem);
            }
        }

    }

    private void reset() {
        ItemStack heldItem = mc.field_71439_g.func_70694_bm();
        if (this.containsItem(heldItem, Items.field_151133_ar)) {
            mc.field_71442_b.func_78769_a(mc.field_71439_g, mc.field_71441_e, heldItem);
        }

        this.handling = false;
    }

    private boolean containsItem(ItemStack itemStack, Item item) {
        return itemStack != null && itemStack.func_77973_b() == item;
    }
}
