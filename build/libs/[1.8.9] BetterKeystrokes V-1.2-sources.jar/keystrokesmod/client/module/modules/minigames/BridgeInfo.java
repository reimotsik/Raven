package keystrokesmod.client.module.modules.minigames;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.Render2DEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiButton;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.EntityArmorStand;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.event.entity.EntityJoinWorldEvent;
import net.minecraftforge.fml.client.config.GuiButtonExt;

import java.awt.*;
import java.io.IOException;

public class BridgeInfo extends Module {
    public static DescriptionSetting a;
    public static TickSetting ep;
    private static final int rgb = (new Color(0, 200, 200)).getRGB();
    private static int hudX = 5;
    private static int hudY = 70;
    private String en = "";
    private BlockPos g1p;
    private BlockPos g2p;
    private boolean q;
    private double d1;
    private double d2;
    private int blc;

    public BridgeInfo() {
        super("Bridge Info", ModuleCategory.minigames);
        this.registerSetting(a = new DescriptionSetting("Only for solos."));
        this.registerSetting(ep = new TickSetting("Edit position", false));
    }

    public void onDisable() {
        this.rv();
    }

    public void guiButtonToggled(TickSetting b) {
        if (b == ep) {
            ep.disable();
            mc.func_147108_a(new BridgeInfo.eh());
        }

    }

    @Subscribe
    public void onTick(TickEvent ev) {
        if (!this.en.isEmpty() && this.ibd()) {
            EntityPlayer enem = null;

            for (Entity e : mc.field_71441_e.field_72996_f) {
                if (e instanceof EntityPlayer) {
                    if (e.func_70005_c_().equals(this.en)) {
                        enem = (EntityPlayer) e;
                    }
                } else if (e instanceof EntityArmorStand) {
                    String g2t = "Jump in to score!";
                    String g1t = "Defend!";
                    if (e.func_70005_c_().contains(g1t)) {
                        this.g1p = e.func_180425_c();
                    } else if (e.func_70005_c_().contains(g2t)) {
                        this.g2p = e.func_180425_c();
                    }
                }
            }

            if (this.g1p != null && this.g2p != null) {
                this.d1 = Utils.Java
                        .round(mc.field_71439_g.func_70011_f(this.g2p.func_177958_n(), this.g2p.func_177956_o(), this.g2p.func_177952_p()) - 1.4D, 1);
                if (this.d1 < 0.0D) {
                    this.d1 = 0.0D;
                }

                this.d2 = enem == null ? 0.0D
                        : Utils.Java.round(enem.func_70011_f(this.g1p.func_177958_n(), this.g1p.func_177956_o(), this.g1p.func_177952_p()) - 1.4D,
                                1);
                if (this.d2 < 0.0D) {
                    this.d2 = 0.0D;
                }
            }

            int blc2 = 0;

            for (int i = 0; i < 9; ++i) {
                ItemStack stack = mc.field_71439_g.field_71071_by.func_70301_a(i);
                if (stack != null && stack.func_77973_b() instanceof ItemBlock
                        && ((ItemBlock) stack.func_77973_b()).field_150939_a.equals(Blocks.field_150406_ce)) {
                    blc2 += stack.field_77994_a;
                }
            }

            this.blc = blc2;
        }
    }

    @Subscribe
    public void onRender2D(Render2DEvent ev) {
        if (Utils.Player.isPlayerInGame() && this.ibd()) {
            if (mc.field_71462_r != null || mc.field_71474_y.field_74330_P) {
                return;
            }

            String t1 = "Enemy: ";
            mc.field_71466_p.func_175065_a(t1 + this.en, (float) hudX, (float) hudY, rgb, true);
            String t2 = "Distance to goal: ";
            mc.field_71466_p.func_175065_a(t2 + this.d1, (float) hudX, (float) (hudY + 11), rgb, true);
            String t3 = "Enemy distance to goal: ";
            mc.field_71466_p.func_175065_a(t3 + this.d2, (float) hudX, (float) (hudY + 22), rgb, true);
            String t4 = "Blocks: ";
            mc.field_71466_p.func_175065_a(t4 + this.blc, (float) hudX, (float) (hudY + 33), rgb, true);
        }

    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof ClientChatReceivedEvent) {
            ClientChatReceivedEvent c = ((ClientChatReceivedEvent) fe.getEvent());

            if (Utils.Player.isPlayerInGame()) {
                String s = Utils.Java.str(c.message.func_150260_c());
                if (s.startsWith(" ")) {
                    String qt = "First player to score 5 goals wins";
                    if (s.contains(qt)) {
                        this.q = true;
                    } else if (this.q && s.contains("Opponent:")) {
                        String n = s.split(":")[1].trim();
                        if (n.contains("[")) {
                            n = n.split("] ")[1];
                        }

                        this.en = n;
                        this.q = false;
                    }
                }
            }
        } else if (fe.getEvent() instanceof EntityJoinWorldEvent) {
            if (((EntityJoinWorldEvent) fe.getEvent()).entity == mc.field_71439_g) {
                this.rv();
            }
        }
    }

    private boolean ibd() {
        if (Utils.Client.isHyp()) {
            for (String s : Utils.Client.getPlayersFromScoreboard()) {
                String s2 = s.toLowerCase();
                String bd = "the brid";
                if (s2.contains("mode") && s2.contains(bd)) {
                    return true;
                }
            }
        }

        return false;
    }

    private void rv() {
        this.en = "";
        this.q = false;
        this.g1p = null;
        this.g2p = null;
        this.d1 = 0.0D;
        this.d2 = 0.0D;
        this.blc = 0;
    }

    static class eh extends GuiScreen {
        final String a = "Enemy: Player123-Distance to goal: 17.2-Enemy distance to goal: 16.3-Blocks: 98";
        GuiButtonExt rp;
        boolean d;
        int miX;
        int miY;
        int maX;
        int maY;
        int aX = 5;
        int aY = 70;
        int laX;
        int laY;
        int lmX;
        int lmY;

        public void func_73866_w_() {
            super.func_73866_w_();
            this.field_146292_n.add(this.rp = new GuiButtonExt(1, this.field_146294_l - 90, 5, 85, 20, "Reset position"));
            this.aX = hudX;
            this.aY = hudY;
        }

        public void func_73863_a(int mX, int mY, float pt) {
            func_73734_a(0, 0, this.field_146294_l, this.field_146295_m, -1308622848);
            int miX = this.aX;
            int miY = this.aY;
            int maX = miX + 140;
            int maY = miY + 41;
            this.d(this.field_146297_k.field_71466_p, this.a);
            this.miX = miX;
            this.miY = miY;
            this.maX = maX;
            this.maY = maY;
            hudX = miX;
            hudY = miY;
            ScaledResolution res = new ScaledResolution(this.field_146297_k);
            int x = res.func_78326_a() / 2 - 84;
            int y = res.func_78328_b() / 2 - 20;
            Utils.HUD.drawColouredText("Edit the HUD position by dragging.", '-', x, y, 2L, 0L, true,
                    this.field_146297_k.field_71466_p);

            try {
                this.func_146269_k();
            } catch (IOException var12) {
            }

            super.func_73863_a(mX, mY, pt);
        }

        private void d(FontRenderer fr, String t) {
            int x = this.miX;
            int y = this.miY;
            String[] var5 = t.split("-");
            int var6 = var5.length;

            for (String s : var5) {
                fr.func_175065_a(s, (float) x, (float) y, rgb, true);
                y += fr.field_78288_b + 2;
            }

        }

        protected void func_146273_a(int mX, int mY, int b, long t) {
            super.func_146273_a(mX, mY, b, t);
            if (b == 0) {
                if (this.d) {
                    this.aX = this.laX + (mX - this.lmX);
                    this.aY = this.laY + (mY - this.lmY);
                } else if (mX > this.miX && mX < this.maX && mY > this.miY && mY < this.maY) {
                    this.d = true;
                    this.lmX = mX;
                    this.lmY = mY;
                    this.laX = this.aX;
                    this.laY = this.aY;
                }

            }
        }

        protected void func_146286_b(int mX, int mY, int s) {
            super.func_146286_b(mX, mY, s);
            if (s == 0) {
                this.d = false;
            }

        }

        public void func_146284_a(GuiButton b) {
            if (b == this.rp) {
                this.aX = hudX = 5;
                this.aY = hudY = 70;
            }

        }

        public boolean func_73868_f() {
            return false;
        }
    }
}
