package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.main.Raven;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.block.Block;
import net.minecraft.block.BlockLiquid;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.BlockPos;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraft.util.MovingObjectPosition.MovingObjectType;
import net.minecraftforge.client.event.DrawBlockHighlightEvent;
import org.lwjgl.input.Mouse;

import net.minecraft.util.MovingObjectPosition.MovingObjectType;
public class AutoPlace extends Module {
    public static DescriptionSetting ds;
    public static TickSetting a, b, top;
    public static SliderSetting c;
    private double lfd;
    private final int d = 25;
    private long l;
    private int f;
    private MovingObjectPosition lm;
    private BlockPos lp;

    public AutoPlace() {
        super("AutoPlace", ModuleCategory.player);
        this.registerSetting(ds = new DescriptionSetting("FD: FPS/80"));
        this.registerSetting(c = new SliderSetting("Frame delay", 8.0D, 0.0D, 30.0D, 1.0D));
        this.registerSetting(a = new TickSetting("Hold right", true));
        this.registerSetting(top = new TickSetting("Place on top & bottom", false));
    }

    public void guiUpdate() {
        if (this.lfd != c.getInput()) {
            this.rv();
        }

        this.lfd = c.getInput();
    }

    public void onDisable() {
        if (a.isToggled()) {
            this.rd(4);
        }

        this.rv();
    }

    @Subscribe
    public void onTick(TickEvent e) {
        Module fastPlace = Raven.moduleManager.getModuleByClazz(FastPlace.class);
        if (a.isToggled() && Mouse.isButtonDown(1) && !mc.field_71439_g.field_71075_bZ.field_75100_b && fastPlace != null
                && !fastPlace.isEnabled()) {
            ItemStack i = mc.field_71439_g.func_70694_bm();
            if (i == null || !(i.func_77973_b() instanceof ItemBlock)) {
                return;
            }

            this.rd(mc.field_71439_g.field_70181_x > 0.0D ? 1 : 1000);
        }

    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof DrawBlockHighlightEvent) {
            if (Utils.Player.isPlayerInGame()) {
                if (mc.field_71462_r == null && !mc.field_71439_g.field_71075_bZ.field_75100_b) {
                    ItemStack i = mc.field_71439_g.func_70694_bm();
                    if (i != null && i.func_77973_b() instanceof ItemBlock) {
                        MovingObjectPosition m = mc.field_71476_x;
                        if (m != null && m.field_72313_a == MovingObjectType.BLOCK
                                && ((m.field_178784_b != EnumFacing.UP && m.field_178784_b != EnumFacing.DOWN) || top.isToggled())) {
                            if (this.lm != null && (double) this.f < c.getInput()) {
                                ++this.f;
                            } else {
                                this.lm = m;
                                BlockPos pos = m.func_178782_a();
                                if (this.lp == null || pos.func_177958_n() != this.lp.func_177958_n() || pos.func_177956_o() != this.lp.func_177956_o()
                                        || pos.func_177952_p() != this.lp.func_177952_p()) {
                                    Block b = mc.field_71441_e.func_180495_p(pos).func_177230_c();
                                    if (b != null && b != Blocks.field_150350_a && !(b instanceof BlockLiquid)) {
                                        if (!a.isToggled() || Mouse.isButtonDown(1)) {
                                            long n = System.currentTimeMillis();
                                            if (n - this.l >= 25L) {
                                                this.l = n;
                                                if (mc.field_71442_b.func_178890_a(mc.field_71439_g, mc.field_71441_e, i,
                                                        pos, m.field_178784_b, m.field_72307_f)) {
                                                    Utils.Client.setMouseButtonState(1, true);
                                                    mc.field_71439_g.func_71038_i();
                                                    mc.func_175597_ag().func_78444_b();
                                                    Utils.Client.setMouseButtonState(1, false);
                                                    this.lp = pos;
                                                    this.f = 0;
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    private void rd(int i) {
        try {
            if (FastPlace.rightClickDelayTimerField != null) {
                FastPlace.rightClickDelayTimerField.set(mc, i);
            }
        } catch (IllegalAccessException | IndexOutOfBoundsException ignored) {
        }
    }

    private void rv() {
        this.lp = null;
        this.lm = null;
        this.f = 0;
    }
}
