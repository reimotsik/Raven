package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.ComboSetting;
import keystrokesmod.client.module.setting.impl.DescriptionSetting;

public class NoFall extends Module {
    public static DescriptionSetting warning;
    public static ComboSetting mode;

    int ticks;
    double dist;
    boolean spoofing;

    public NoFall() {
        super("NoFall", ModuleCategory.player);

        this.registerSetting(warning = new DescriptionSetting("HypixelSpoof silent flags."));
        this.registerSetting(mode = new ComboSetting("Mode", Mode.Spoof));
    }

    @Subscribe
    public void onTick(TickEvent e) {
        switch ((Mode) mode.getMode()) {
        case Spoof:
            if ((double) mc.field_71439_g.field_70143_R > 2.5D) {
                mc.field_71439_g.field_70122_E = true;
            }
            break;

        case HypixelSpoof:
            if (mc.field_71439_g.field_70122_E) {
                ticks = 0;
                dist = 0;
                spoofing = false;
            } else {
                if (mc.field_71439_g.field_70143_R > 2) {
                    if (spoofing) {
                        ticks++;
                        mc.field_71439_g.field_70122_E = true;

                        if (ticks >= 2) {
                            spoofing = false;
                            ticks = 0;
                            dist = mc.field_71439_g.field_70143_R;
                        }
                    } else {
                        if (mc.field_71439_g.field_70143_R - dist > 2) {
                            spoofing = true;
                        }
                    }
                }
            }
            break;

        case Verus:
            if (mc.field_71439_g.field_70122_E) {
                dist = 0;
                spoofing = false;
            } else {
                if (mc.field_71439_g.field_70143_R > 2) {
                    if (spoofing) {
                        mc.field_71439_g.field_70122_E = true;
                        mc.field_71439_g.field_70181_x = 0;
                        spoofing = false;
                        dist = mc.field_71439_g.field_70143_R;
                    } else {
                        if (mc.field_71439_g.field_70143_R - dist > 2) {
                            spoofing = true;
                        }
                    }
                }
            }
            break;
        }
    }

    public enum Mode {
        Spoof, HypixelSpoof, Verus
    }
}
