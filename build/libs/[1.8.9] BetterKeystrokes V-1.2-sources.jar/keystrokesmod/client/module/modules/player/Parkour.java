package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.utils.CoolDown;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.settings.KeyBinding;
import org.lwjgl.input.Keyboard;

public class Parkour extends Module {

    private final CoolDown cd = new CoolDown(1);

    public Parkour() {
        super("Parkour", ModuleCategory.player);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame())
            return;

        if (!Keyboard.isKeyDown(mc.field_71474_y.field_74314_A.func_151463_i()) && cd.firstFinish())
            KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), false);

        if (mc.field_71439_g.field_70122_E && Utils.Player.playerOverAir()
                && (mc.field_71439_g.field_70159_w != 0 || mc.field_71439_g.field_70179_y != 0)) {
            KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), true);
            cd.setCooldown(10);
            cd.start();
        }
    }

}
