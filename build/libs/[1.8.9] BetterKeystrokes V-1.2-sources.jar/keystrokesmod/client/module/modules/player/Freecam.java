package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.ForgeEvent;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.SliderSetting;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.entity.EntityOtherPlayerMP;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderWorldLastEvent;
import org.lwjgl.input.Keyboard;

import java.awt.*;

public class Freecam extends Module {
    public static SliderSetting a;
    public static TickSetting b;
    private final double toRad = 0.017453292519943295D;
    public static EntityOtherPlayerMP en;
    private int[] lcc = { Integer.MAX_VALUE, 0 };
    private final float[] sAng = { 0.0F, 0.0F };

    public Freecam() {
        super("Freecam", ModuleCategory.player);
        this.registerSetting(a = new SliderSetting("Speed", 2.5D, 0.5D, 10.0D, 0.5D));
        this.registerSetting(b = new TickSetting("Disable on damage", true));
    }

    @Override
    public void onEnable() {
        if (!Utils.Player.isPlayerInGame()) {
            return;
        }
        if (!mc.field_71439_g.field_70122_E) {
            this.disable();
        } else {
            en = new EntityOtherPlayerMP(mc.field_71441_e, mc.field_71439_g.func_146103_bH());
            en.func_82149_j(mc.field_71439_g);
            this.sAng[0] = en.field_70759_as = mc.field_71439_g.field_70759_as;
            this.sAng[1] = mc.field_71439_g.field_70125_A;
            en.func_70016_h(0.0D, 0.0D, 0.0D);
            en.func_82142_c(true);
            mc.field_71441_e.func_73027_a(-8008, en);
            mc.func_175607_a(en);
        }
    }

    public void onDisable() {
        if (en != null) {
            mc.func_175607_a(mc.field_71439_g);
            mc.field_71439_g.field_70177_z = mc.field_71439_g.field_70759_as = this.sAng[0];
            mc.field_71439_g.field_70125_A = this.sAng[1];
            mc.field_71441_e.func_72900_e(en);
            en = null;
        }

        this.lcc = new int[] { Integer.MAX_VALUE, 0 };
        int rg = 1;
        int x = mc.field_71439_g.field_70176_ah;
        int z = mc.field_71439_g.field_70164_aj;

        for (int x2 = -1; x2 <= 1; ++x2) {
            for (int z2 = -1; z2 <= 1; ++z2) {
                int a = x + x2;
                int b = z + z2;
                mc.field_71441_e.func_147458_c(a * 16, 0, b * 16, a * 16 + 15, 256, b * 16 + 15);
            }
        }

    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (!Utils.Player.isPlayerInGame() || en == null)
            return;
        if (b.isToggled() && mc.field_71439_g.field_70737_aN != 0) {
            this.disable();
        } else {
            mc.field_71439_g.func_70031_b(false);
            mc.field_71439_g.field_70701_bs = 0.0F;
            mc.field_71439_g.field_70702_br = 0.0F;
            en.field_70177_z = en.field_70759_as = mc.field_71439_g.field_70177_z;
            en.field_70125_A = mc.field_71439_g.field_70125_A;
            double s = 0.215D * a.getInput();
            EntityOtherPlayerMP var10000;
            double rad;
            double dx;
            double dz;
            if (Keyboard.isKeyDown(mc.field_71474_y.field_74351_w.func_151463_i())) {
                rad = (double) en.field_70759_as * 0.017453292519943295D;
                dx = -1.0D * Math.sin(rad) * s;
                dz = Math.cos(rad) * s;
                var10000 = en;
                var10000.field_70165_t += dx;
                var10000 = en;
                var10000.field_70161_v += dz;
            }

            if (Keyboard.isKeyDown(mc.field_71474_y.field_74368_y.func_151463_i())) {
                rad = (double) en.field_70759_as * 0.017453292519943295D;
                dx = -1.0D * Math.sin(rad) * s;
                dz = Math.cos(rad) * s;
                var10000 = en;
                var10000.field_70165_t -= dx;
                var10000 = en;
                var10000.field_70161_v -= dz;
            }

            if (Keyboard.isKeyDown(mc.field_71474_y.field_74370_x.func_151463_i())) {
                rad = (double) (en.field_70759_as - 90.0F) * 0.017453292519943295D;
                dx = -1.0D * Math.sin(rad) * s;
                dz = Math.cos(rad) * s;
                var10000 = en;
                var10000.field_70165_t += dx;
                var10000 = en;
                var10000.field_70161_v += dz;
            }

            if (Keyboard.isKeyDown(mc.field_71474_y.field_74366_z.func_151463_i())) {
                rad = (double) (en.field_70759_as + 90.0F) * 0.017453292519943295D;
                dx = -1.0D * Math.sin(rad) * s;
                dz = Math.cos(rad) * s;
                var10000 = en;
                var10000.field_70165_t += dx;
                var10000 = en;
                var10000.field_70161_v += dz;
            }

            if (Keyboard.isKeyDown(mc.field_71474_y.field_74314_A.func_151463_i())) {
                var10000 = en;
                var10000.field_70163_u += 0.93D * s;
            }

            if (Keyboard.isKeyDown(mc.field_71474_y.field_74311_E.func_151463_i())) {
                var10000 = en;
                var10000.field_70163_u -= 0.93D * s;
            }

            mc.field_71439_g.func_70095_a(false);
            if (this.lcc[0] != Integer.MAX_VALUE && (this.lcc[0] != en.field_70176_ah || this.lcc[1] != en.field_70164_aj)) {
                int x = en.field_70176_ah;
                int z = en.field_70164_aj;
                mc.field_71441_e.func_147458_c(x * 16, 0, z * 16, x * 16 + 15, 256, z * 16 + 15);
            }

            this.lcc[0] = en.field_70176_ah;
            this.lcc[1] = en.field_70164_aj;
        }
    }

    @Subscribe
    public void onForgeEvent(ForgeEvent fe) {
        if (fe.getEvent() instanceof RenderWorldLastEvent) {
            if (Utils.Player.isPlayerInGame()) {
                mc.field_71439_g.field_71155_g = mc.field_71439_g.field_71164_i = 700.0F;
                Utils.HUD.drawBoxAroundEntity(mc.field_71439_g, 1, 0.0D, 0.0D, Color.green.getRGB(), false);
                Utils.HUD.drawBoxAroundEntity(mc.field_71439_g, 2, 0.0D, 0.0D, Color.green.getRGB(), false);
            }
        } else if (fe.getEvent() instanceof MouseEvent) {
            MouseEvent e = ((MouseEvent) fe.getEvent());

            if (Utils.Player.isPlayerInGame() && e.button != -1) {
                e.setCanceled(true);
            }
        }
    }
}
