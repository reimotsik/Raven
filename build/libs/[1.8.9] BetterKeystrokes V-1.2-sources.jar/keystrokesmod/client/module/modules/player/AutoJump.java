package keystrokesmod.client.module.modules.player;

import com.google.common.eventbus.Subscribe;
import keystrokesmod.client.event.impl.TickEvent;
import keystrokesmod.client.module.Module;
import keystrokesmod.client.module.setting.impl.TickSetting;
import keystrokesmod.client.utils.Utils;
import net.minecraft.client.settings.KeyBinding;

public class AutoJump extends Module {
    public static TickSetting b;
    private boolean c;

    public AutoJump() {
        super("AutoJump", ModuleCategory.player);
        this.registerSetting(b = new TickSetting("Cancel when shifting", true));
    }

    public void onDisable() {
        this.ju(this.c = false);
    }

    @Subscribe
    public void onTick(TickEvent e) {
        if (Utils.Player.isPlayerInGame()) {
            if (mc.field_71439_g.field_70122_E && (!b.isToggled() || !mc.field_71439_g.func_70093_af())) {
                if (mc.field_71441_e.func_72945_a(mc.field_71439_g, mc.field_71439_g.func_174813_aQ()
                        .func_72317_d(mc.field_71439_g.field_70159_w / 3.0D, -1.0D, mc.field_71439_g.field_70179_y / 3.0D)).isEmpty()) {
                    this.ju(this.c = true);
                } else if (this.c) {
                    this.ju(this.c = false);
                }
            } else if (this.c) {
                this.ju(this.c = false);
            }

        }
    }

    private void ju(boolean ju) {
        KeyBinding.func_74510_a(mc.field_71474_y.field_74314_A.func_151463_i(), ju);
    }
}
